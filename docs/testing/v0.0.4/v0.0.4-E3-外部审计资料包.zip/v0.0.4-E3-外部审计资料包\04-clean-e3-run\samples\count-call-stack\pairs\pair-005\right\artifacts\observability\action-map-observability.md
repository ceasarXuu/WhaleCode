﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-005\right\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-005\right\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-005\right\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 5
- edges: 4
- agents: 0
- collab tool calls: 0
- map runtime events: 138
- output contracts: 2
- fact sources: 2
- accepted results: 4
- questioned/invalid results: 0
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: False
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: final_artifact_hash_missing
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=2 |  |
| required_fact_source_missing | True | at least one fact source | factSources=2 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=17, resultWithClaimEvidence=4 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=17, validityTransitions=7 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | False | each final artifact path resolves to a SHA-256 hash | missingHash=1 | task:task-1\|artifact:W:/app/output.txt |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 2 |
| factSourceCount | 2 |
| activeFactCount | 1 |
| resultCount | 17 |
| acceptedResultCount | 4 |
| questionedOrInvalidResultCount | 0 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 4 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 7 |
| cognitiveStateUpdateCount | 27 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 1 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Analyze profiling stack traces | Find a profiling log file, parse stack traces, identify unique call sites based on top 3 frames, and output top 10 most frequent ones to output.txt | 2 | 2 | 1 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-5 | final_synthesis | Final synthesis - summarize results | completed | 0 | 1 | 0 | 0 | 0 | 0 |
| node-1 | inspect_code_context | Find and inspect the log file | completed | 0 | 5 | 1 | 0 | 1 | 0 |
| node-2 | implement_solution | Parse stack traces and generate output.txt | completed | 0 | 4 | 1 | 0 | 0 | 0 |
| node-4 | smoke_test | Validate output.txt format and content | blocked | 0 | 5 | 1 | 0 | 1 | 0 |
| node-3 | final_synthesis | Wrap up analysis | blocked | 0 | 2 | 1 | 0 | 0 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:W:/app/output.txt | task-1 | W:/app/output.txt |  | result-9, result-16, result-11 | oc-1, oc-2 | cl-4, cl-6, cl-5 | artifactRef=W:/app/output.txt, artifactRef=W:/app/log.stack, validatorRef=Get-Content and regex validation, validatorRef=PowerShell output validation, artifactRef=User request requires output | Get-Content and regex validation, PowerShell output validation, PowerShell Get-Content validation with regex matching |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-17 | node-5 | unreviewed |  |  |  |  |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | unreviewed |  |  |  |  |
| result-4 | node-1 | unreviewed |  |  |  |  |
| result-5 | node-1 | accepted | cl-1 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/log.stack","validatorRef":null} |  | Confirmed log.stack file format successfully |
| result-6 | node-2 | unreviewed |  |  |  |  |
| result-7 | node-2 | unreviewed |  |  |  |  |
| result-8 | node-2 | unreviewed |  |  |  |  |
| result-9 | node-2 | accepted | cl-4 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/output.txt","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/log.stack","validatorRef":null} |  | Output verified - correctly formatted with 646 traces, 318 unique sites, 3,158,871 analyzed, top 10 sorted descending |
| result-12 | node-4 | unreviewed |  |  |  |  |
| result-13 | node-4 | unreviewed |  |  |  |  |
| result-14 | node-4 | unreviewed |  |  |  |  |
| result-15 | node-4 | unreviewed |  |  |  |  |
| result-16 | node-4 | accepted | cl-6 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/output.txt","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":null,"validatorRef":"PowerShell output validation"} | PowerShell Get-Content validation with regex matching | Output file validated successfully: correct header format, 10 entries sorted descending, no 'in' prefix, proper frame structure |
| result-10 | node-3 | unreviewed |  |  |  |  |
| result-11 | node-3 | accepted | cl-5 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/output.txt","validatorRef":null} |  | final_synthesis blocked by runtime despite criteria being satisfied; moved to smoke_test for explicit validation |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-2 | node-3 |
| node-2 | node-4 |
| node-2 | node-5 |

## Timeline

- 2026-06-15T20:18:47.218Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T20:18:51.384Z **task_created** task created: task-1 Analyze profiling stack traces
- 2026-06-15T20:18:51.385Z **map_created** map created: map-1 Analyze profiling stack traces
- 2026-06-15T20:18:51.385Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:18:51.386Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:18:51.386Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:18:51.387Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T20:18:51.387Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T20:18:51.387Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T20:18:51.388Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:18:58.321Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T20:18:58.321Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:18:58.322Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-2
- 2026-06-15T20:18:58.323Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:18:58.323Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T20:18:58.324Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:19:04.856Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T20:19:04.857Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T20:19:04.857Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:19:10.358Z **node_result_recorded** node result recorded: node-1 / result-2 action=read
- 2026-06-15T20:19:10.359Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T20:19:10.360Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:19:14.806Z **node_result_recorded** node result recorded: node-1 / result-3 action=read
- 2026-06-15T20:19:14.807Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-3 tags=tool_success
- 2026-06-15T20:19:14.808Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:19:24.194Z **node_result_recorded** node result recorded: node-1 / result-4 action=read
- 2026-06-15T20:19:24.195Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-4 tags=tool_success
- 2026-06-15T20:19:24.195Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:19:34.744Z **tool_action_blocked** tool action blocked: node-1 edit via shell_command
- 2026-06-15T20:19:34.747Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:19:37.476Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-2
- 2026-06-15T20:19:37.476Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:19:40.276Z **node_result_recorded** node result recorded: node-1 / result-5
- 2026-06-15T20:19:40.277Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T20:19:40.277Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T20:19:40.277Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T20:19:40.278Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T20:19:40.278Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T20:19:40.278Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:19:49.739Z **result_validity_changed** result validity: result-5 -> accepted
- 2026-06-15T20:19:49.739Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:19:58.958Z **node_result_recorded** node result recorded: node-2 / result-6 action=edit
- 2026-06-15T20:19:58.959Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-6 tags=tool_success
- 2026-06-15T20:19:58.960Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:20:15.311Z **node_result_recorded** node result recorded: node-2 / result-7 action=edit
- 2026-06-15T20:20:15.312Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-7 tags=tool_success
- 2026-06-15T20:20:15.313Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:20:20.205Z **node_result_recorded** node result recorded: node-2 / result-8 action=read
- 2026-06-15T20:20:20.206Z **taskspace_trace_event_recorded** trace event: trace-7 result=result-8 tags=tool_success
- 2026-06-15T20:20:20.206Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:20:25.619Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:20:25.619Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:20:25.619Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:20:25.620Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:20:28.299Z **node_result_recorded** node result recorded: node-2 / result-9
- 2026-06-15T20:20:28.299Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T20:20:28.300Z **node_status_changed** node status: node-2 running -> completed
- 2026-06-15T20:20:28.300Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T20:20:28.300Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T20:20:28.301Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T20:20:28.301Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:20:34.488Z **result_validity_changed** result validity: result-9 -> accepted
- 2026-06-15T20:20:34.489Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:20:37.959Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T20:20:37.959Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-9
- 2026-06-15T20:20:37.960Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:20:42.643Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact cl-3
- 2026-06-15T20:20:42.643Z **cognitive_state_updated** cognitive state updated: result_adoption.fact result-9
- 2026-06-15T20:20:42.643Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:20:46.985Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:20:46.985Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:20:46.986Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:20:46.986Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:20:51.785Z **result_validity_changed** result validity: result-9 -> accepted
- 2026-06-15T20:20:51.785Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:20:54.051Z **result_validity_changed** result validity: result-5 -> accepted
- 2026-06-15T20:20:54.052Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:20:55.627Z **cognitive_state_updated** cognitive state updated: result_adoption result-9
- 2026-06-15T20:20:55.628Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:20:59.229Z **cognitive_state_updated** cognitive state updated: result_adoption result-5
- 2026-06-15T20:20:59.229Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:21:12.562Z **node_result_recorded** node result recorded: node-3 / result-10 action=read
- 2026-06-15T20:21:12.562Z **taskspace_trace_event_recorded** trace event: trace-8 result=result-10 tags=tool_success
- 2026-06-15T20:21:12.563Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:21:17.888Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T20:21:17.888Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T20:21:17.889Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:21:21.985Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-6
- 2026-06-15T20:21:21.986Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:21:29.774Z **result_validity_changed** result validity: result-9 -> accepted
- 2026-06-15T20:21:29.775Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:21:35.984Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:21:35.985Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:21:35.985Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:21:35.985Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:21:41.456Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T20:21:41.457Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:21:43.429Z **node_result_recorded** node result recorded: node-3 / result-11
- 2026-06-15T20:21:43.429Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T20:21:43.430Z **node_status_changed** node status: node-3 running -> blocked
- 2026-06-15T20:21:43.430Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:21:44.811Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T20:21:44.812Z **lease_created** lease created: lease-4 on node-4
- 2026-06-15T20:21:44.812Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:21:53.605Z **result_validity_changed** result validity: result-11 -> accepted
- 2026-06-15T20:21:53.605Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:22:07.937Z **node_result_recorded** node result recorded: node-4 / result-12 action=read
- 2026-06-15T20:22:07.938Z **taskspace_trace_event_recorded** trace event: trace-9 result=result-12 tags=tool_success
- 2026-06-15T20:22:07.938Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:22:15.115Z **tool_action_blocked** tool action blocked: node-4 edit via shell_command
- 2026-06-15T20:22:15.117Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:22:22.081Z **node_result_recorded** node result recorded: node-4 / result-13 action=read
- 2026-06-15T20:22:22.082Z **taskspace_trace_event_recorded** trace event: trace-10 result=result-13 tags=tool_success
- 2026-06-15T20:22:22.082Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:22:27.023Z **node_result_recorded** node result recorded: node-4 / result-14 action=read
- 2026-06-15T20:22:27.024Z **taskspace_trace_event_recorded** trace event: trace-11 result=result-14 tags=tool_success
- 2026-06-15T20:22:27.024Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:22:38.799Z **node_result_recorded** node result recorded: node-4 / result-15 action=read
- 2026-06-15T20:22:38.800Z **taskspace_trace_event_recorded** trace event: trace-12 result=result-15 tags=tool_success
- 2026-06-15T20:22:38.801Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:22:44.829Z **node_result_recorded** node result recorded: node-4 / result-16
- 2026-06-15T20:22:44.830Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T20:22:44.830Z **node_status_changed** node status: node-4 running -> blocked
- 2026-06-15T20:22:44.830Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:22:47.737Z **result_validity_changed** result validity: result-16 -> accepted
- 2026-06-15T20:22:47.738Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:22:49.842Z **node_status_changed** node status: node-5 pending -> ready
- 2026-06-15T20:22:49.843Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:22:51.200Z **node_status_changed** node status: node-5 ready -> running
- 2026-06-15T20:22:51.200Z **lease_created** lease created: lease-5 on node-5
- 2026-06-15T20:22:51.200Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:22:53.565Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-7
- 2026-06-15T20:22:53.566Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-8
- 2026-06-15T20:22:53.566Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:23:00.822Z **node_result_recorded** node result recorded: node-5 / result-17
- 2026-06-15T20:23:00.822Z **lease_released** lease released: lease-5, reason=result_recorded
- 2026-06-15T20:23:00.823Z **node_status_changed** node status: node-5 running -> completed
- 2026-06-15T20:23:00.823Z **snapshot_updated** snapshot updated: maps=1 nodes=5

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
