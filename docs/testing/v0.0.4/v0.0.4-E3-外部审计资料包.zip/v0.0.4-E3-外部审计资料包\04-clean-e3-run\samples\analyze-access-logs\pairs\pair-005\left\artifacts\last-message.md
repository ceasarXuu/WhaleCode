The report has been created at **`/app/report.txt`** (i.e. `W:\app\report.txt`). Here's the summary:

| Metric | Value |
|---|---|
| **Total requests** | 2000 |
| **Unique IP addresses** | 273 |
| **Top URL** | `/order-confirmation`: 54 requests |
| **2nd URL** | `/product/456`: 53 requests |
| **3rd URL** | `/about.html`: 52 requests |
| **404 errors** | 83 |

The report file contains exactly the format requested:

```
Total requests: 2000
Unique IP addresses: 273
Top 3 URLs:
  /order-confirmation: 54
  /product/456: 53
  /about.html: 52
404 errors: 83
```