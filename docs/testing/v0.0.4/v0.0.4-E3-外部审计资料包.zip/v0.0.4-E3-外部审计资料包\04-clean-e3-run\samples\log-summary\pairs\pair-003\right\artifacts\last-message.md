任务完成！以下是工作摘要：

## 扫描结果 — `/app/logs/` 中的 `.log` 文件

共找到 **3 个日志文件**，逐行扫描计数：

| 严重级别 | 行数 |
|---------|------|
| **ERROR** | **4** |
| **WARNING** | **3** |
| **INFO** | **8** |

## 输出文件

`/app/summary.csv` 已创建，内容如下：

```
severity,count
ERROR,4
WARNING,3
INFO,8
```

格式为有效的 CSV，包含标题行和三个数据行。可通过 `Get-Content W:\app\summary.csv` 查看。