The task is complete. Here's a summary:

**Investigation Phase**
- Scanned `/app/logs/` and found 3 log files: `app1.log`, `app2.log`, `db.log`
- Each file contains 5 structured log lines

**Count Results**
| Severity | Lines Found |
|----------|------------|
| **ERROR**   | 4  |
| **WARNING** | 3  |
| **INFO**    | 8  |

**Output**
Created `/app/summary.csv` with valid CSV format:
```
severity,count
ERROR,4
WARNING,3
INFO,8
```

**Validation** ✅
- File contains exactly 4 lines (header + 3 data rows)
- Header reads `severity,count`
- All three data rows match the expected severity and count values

The CSV file is ready at `W:\app\summary.csv`.