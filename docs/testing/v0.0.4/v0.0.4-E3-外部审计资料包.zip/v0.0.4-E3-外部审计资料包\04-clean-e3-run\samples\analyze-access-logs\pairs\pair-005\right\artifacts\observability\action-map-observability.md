﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-005\right\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-005\right\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-005\right\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 2
- nodes: 11
- edges: 9
- agents: 2
- collab tool calls: 11
- map runtime events: 219
- output contracts: 2
- fact sources: 3
- accepted results: 5
- questioned/invalid results: 3
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: False
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: audit_why_chain_missing, final_artifact_hash_missing
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=2 |  |
| required_fact_source_missing | True | at least one fact source | factSources=3 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=17, resultWithClaimEvidence=8 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=17, validityTransitions=10 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | False | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=1 | task-2/oc-final |
| final_artifact_hash_missing | False | each final artifact path resolves to a SHA-256 hash | missingHash=1 | task:task-1\|artifact:W:/app/report.txt |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 2 |
| factSourceCount | 3 |
| activeFactCount | 1 |
| resultCount | 17 |
| acceptedResultCount | 5 |
| questionedOrInvalidResultCount | 3 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 8 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 10 |
| cognitiveStateUpdateCount | 54 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 1 |
| finalArtifactMissingWhyChainCount | 1 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-2 | pending | Final wrap-up | Provide final answer summarizing the completed work. | 1 | 1 | 0 |
| task-1 | active | Analyze access log and generate report | Read /app/access_log and create /app/report.txt with request stats including total requests, unique IPs, top 3 URLs, and 404 count. | 1 | 2 | 1 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-2 | implement_solution | Create report.txt | blocked | 0 | 1 | 0 | 1 | 0 | 0 |
| node-9 | final_synthesis | Final summary | ready | 0 | 0 | 0 | 0 | 0 | 0 |
| node-5 | inspect_code_context | Verify URL extraction method | completed | 1 | 3 | 1 | 0 | 0 | 0 |
| node-4 | inspect_code_context | Write report file | blocked | 1 | 1 | 1 | 0 | 1 | 0 |
| node-6 | inspect_code_context | Verify 404 count method | blocked | 0 | 1 | 0 | 1 | 0 | 0 |
| node-10 | final_synthesis | Final summary | ready | 0 | 0 | 0 | 0 | 0 | 0 |
| node-3 | smoke_test | Create and validate report.txt | blocked | 0 | 1 | 0 | 1 | 0 | 0 |
| node-1 | inspect_code_context | Inspect access log and generate report | completed | 0 | 4 | 1 | 0 | 1 | 0 |
| node-7 | implement_solution | Write report.txt | completed | 0 | 2 | 1 | 0 | 0 | 0 |
| node-8 | smoke_test | Validate report.txt | blocked | 0 | 3 | 1 | 0 | 0 | 0 |
| node-11 | final_synthesis | Final synthesis | completed | 0 | 1 | 0 | 0 | 0 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:W:/app/report.txt | task-1 | W:/app/report.txt |  | result-12, result-15 | oc-1 | c-write-success, c-validate-pass | artifactRef=W:/app/report.txt, validatorRef=Validate-ReportContent | Validate-ReportContent |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-5 | node-2 | questioned | c-5 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"/app/access_log","validatorRef":null} |  | Edit blocked by runtime tool budget, not by a real task issue. The analysis itself is complete. |
| result-8 | node-5 | unreviewed |  |  |  |  |
| result-9 | node-5 | unreviewed |  |  |  |  |
| result-10 | node-5 | accepted | c-verify-urls | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"/app/access_log","validatorRef":null} |  | URL extraction and count verification confirmed by subagent Raman. |
| result-7 | node-4 | accepted | c-node4 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"/app/access_log","validatorRef":null} |  | Subagent correctly identified that writing requires implement_solution node. |
| result-16 | node-6 | questioned | c-node6 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"/app/access_log","validatorRef":null} |  | Node created unnecessarily for runtime delegation requirement, not a real investigation. |
| result-6 | node-3 | questioned | c-6 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"/app/access_log","validatorRef":null} |  | Blocked by runtime budget enforcement, not a real test failure. |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | unreviewed |  |  |  |  |
| result-4 | node-1 | accepted | c-write-blocked | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"/app/access_log","validatorRef":null} |  | URL verification confirmed. Report writing needs implement_solution node. |
| result-11 | node-7 | unreviewed |  |  |  |  |
| result-12 | node-7 | accepted | c-write-success | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/report.txt","validatorRef":null} |  | Shell command wrote file and verified content by reading it back. |
| result-13 | node-8 | unreviewed |  |  |  |  |
| result-14 | node-8 | unreviewed |  |  |  |  |
| result-15 | node-8 | accepted | c-validate-pass | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/report.txt","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":null,"validatorRef":"Validate-ReportContent"} |  | Validation passed all checks but runtime did not register shell_command as test action. |
| result-17 | node-11 | unreviewed |  |  |  |  |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-1 | node-3 |
| node-1 | node-4 |
| node-1 | node-5 |
| node-1 | node-6 |
| node-5 | node-7 |
| node-7 | node-8 |
| node-7 | node-9 |
| node-7 | node-11 |

## Timeline

- 2026-06-15T18:45:00.270Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T18:45:04.104Z **task_created** task created: task-1 Analyze access log and generate report
- 2026-06-15T18:45:04.104Z **map_created** map created: map-1 Analyze access log and generate report
- 2026-06-15T18:45:04.104Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:45:04.105Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:45:04.105Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:45:04.106Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:45:04.106Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:45:04.106Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T18:45:04.107Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:45:07.634Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T18:45:07.634Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:45:07.635Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T18:45:07.636Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:45:10.446Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T18:45:10.446Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T18:45:10.447Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:45:17.146Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T18:45:17.147Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T18:45:17.148Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:45:29.956Z **node_result_recorded** node result recorded: node-1 / result-2 action=read
- 2026-06-15T18:45:29.957Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T18:45:29.958Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:45:37.439Z **node_result_recorded** node result recorded: node-1 / result-3 action=read
- 2026-06-15T18:45:37.440Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-3 tags=tool_success
- 2026-06-15T18:45:37.440Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:45:39.460Z **tool_action_blocked** tool action blocked: node-1 edit via apply_patch
- 2026-06-15T18:45:39.461Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:45:42.483Z **node_result_recorded** node result recorded: node-1 / result-4
- 2026-06-15T18:45:42.483Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T18:45:42.484Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T18:45:42.484Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T18:45:42.484Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T18:45:42.485Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T18:45:42.485Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:45:48.568Z **result_validity_changed** result validity: result-4 -> accepted
- 2026-06-15T18:45:48.568Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:46:11.124Z **node_result_recorded** node result recorded: node-2 / result-5
- 2026-06-15T18:46:11.125Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T18:46:11.125Z **node_status_changed** node status: node-2 running -> blocked
- 2026-06-15T18:46:11.126Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:46:17.351Z **result_validity_changed** result validity: result-5 -> questioned
- 2026-06-15T18:46:17.352Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:46:19.675Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T18:46:19.676Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T18:46:19.676Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T18:46:19.676Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:46:27.531Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T18:46:27.531Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:46:33.746Z **node_status_changed** node status: node-5 pending -> ready
- 2026-06-15T18:46:33.746Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T18:46:35.644Z **node_status_changed** node status: node-6 pending -> ready
- 2026-06-15T18:46:35.644Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:46:43.575Z **node_result_recorded** node result recorded: node-3 / result-6
- 2026-06-15T18:46:43.575Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T18:46:43.576Z **node_status_changed** node status: node-3 running -> blocked
- 2026-06-15T18:46:43.576Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:46:46.549Z **result_validity_changed** result validity: result-6 -> questioned
- 2026-06-15T18:46:46.550Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:15.138Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-report
- 2026-06-15T18:47:15.139Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:35.232Z **cognitive_state_updated** cognitive state updated: subagent_plan.recorded subagent-plan-1
- 2026-06-15T18:47:35.232Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:37.929Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T18:47:37.929Z **lease_created** lease created: lease-4 on node-4
- 2026-06-15T18:47:37.930Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:38.050Z **lease_attached** agent attached: /root/write_report_file -> node-4
- 2026-06-15T18:47:38.051Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:40.101Z **tool_action_blocked** tool action blocked: node-4 edit via shell_command
- 2026-06-15T18:47:40.101Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:41.052Z **cognitive_state_updated** cognitive state updated: subagent_plan.recorded subagent-plan-2
- 2026-06-15T18:47:41.053Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:43.731Z **node_status_changed** node status: node-5 ready -> running
- 2026-06-15T18:47:43.732Z **lease_created** lease created: lease-5 on node-5
- 2026-06-15T18:47:43.732Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:43.844Z **lease_attached** agent attached: /root/verify_urls -> node-5
- 2026-06-15T18:47:43.844Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:45.356Z **node_result_recorded** node result recorded: node-4 / result-7
- 2026-06-15T18:47:45.357Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T18:47:45.357Z **node_status_changed** node status: node-4 running -> blocked
- 2026-06-15T18:47:45.357Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:48.894Z **node_result_recorded** node result recorded: node-5 / result-8 action=read
- 2026-06-15T18:47:48.894Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:47:56.028Z **node_result_recorded** node result recorded: node-5 / result-9 action=read
- 2026-06-15T18:47:56.028Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:48:02.371Z **node_result_recorded** node result recorded: node-5 / result-10
- 2026-06-15T18:48:02.372Z **lease_released** lease released: lease-5, reason=result_recorded
- 2026-06-15T18:48:02.372Z **node_status_changed** node status: node-5 running -> completed
- 2026-06-15T18:48:02.373Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:48:06.452Z **result_validity_changed** result validity: result-4 -> accepted
- 2026-06-15T18:48:06.453Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:48:10.332Z **result_validity_changed** result validity: result-4 -> accepted
- 2026-06-15T18:48:10.333Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T18:48:13.329Z **node_status_changed** node status: node-7 pending -> ready
- 2026-06-15T18:48:13.330Z **node_status_changed** node status: node-7 ready -> running
- 2026-06-15T18:48:13.330Z **lease_created** lease created: lease-6 on node-7
- 2026-06-15T18:48:13.331Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T18:48:21.952Z **result_validity_changed** result validity: result-7 -> accepted
- 2026-06-15T18:48:21.953Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T18:48:32.797Z **result_validity_changed** result validity: result-10 -> accepted
- 2026-06-15T18:48:32.798Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T18:48:38.262Z **node_result_recorded** node result recorded: node-7 / result-11 action=edit
- 2026-06-15T18:48:38.263Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-11 tags=tool_success
- 2026-06-15T18:48:38.263Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T18:48:40.769Z **node_result_recorded** node result recorded: node-7 / result-12
- 2026-06-15T18:48:40.773Z **lease_released** lease released: lease-6, reason=result_recorded
- 2026-06-15T18:48:40.774Z **node_status_changed** node status: node-7 running -> completed
- 2026-06-15T18:48:40.775Z **node_status_changed** node status: node-8 pending -> ready
- 2026-06-15T18:48:40.775Z **node_status_changed** node status: node-8 ready -> running
- 2026-06-15T18:48:40.776Z **lease_created** lease created: lease-7 on node-8
- 2026-06-15T18:48:40.776Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:48:44.601Z **result_validity_changed** result validity: result-12 -> accepted
- 2026-06-15T18:48:44.601Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:48:53.274Z **node_result_recorded** node result recorded: node-8 / result-13 action=read
- 2026-06-15T18:48:53.275Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-13 tags=tool_success
- 2026-06-15T18:48:53.276Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:49:05.104Z **node_result_recorded** node result recorded: node-8 / result-14 action=read
- 2026-06-15T18:49:05.105Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-14 tags=tool_success
- 2026-06-15T18:49:05.106Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:49:13.152Z **node_result_recorded** node result recorded: node-8 / result-15
- 2026-06-15T18:49:13.152Z **lease_released** lease released: lease-7, reason=result_recorded
- 2026-06-15T18:49:13.153Z **node_status_changed** node status: node-8 running -> blocked
- 2026-06-15T18:49:13.153Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:49:15.888Z **result_validity_changed** result validity: result-15 -> accepted
- 2026-06-15T18:49:15.888Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:49:19.963Z **node_status_changed** node status: node-6 ready -> running
- 2026-06-15T18:49:19.964Z **lease_created** lease created: lease-8 on node-6
- 2026-06-15T18:49:19.964Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:49:22.257Z **node_result_recorded** node result recorded: node-6 / result-16
- 2026-06-15T18:49:22.257Z **lease_released** lease released: lease-8, reason=result_recorded
- 2026-06-15T18:49:22.258Z **node_status_changed** node status: node-6 running -> blocked
- 2026-06-15T18:49:22.258Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:49:25.089Z **result_validity_changed** result validity: result-16 -> questioned
- 2026-06-15T18:49:25.089Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:49:27.748Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-done
- 2026-06-15T18:49:27.748Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-verify
- 2026-06-15T18:49:27.749Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T18:49:29.837Z **node_status_changed** node status: node-9 pending -> ready
- 2026-06-15T18:49:29.837Z **node_status_changed** node status: node-9 ready -> running
- 2026-06-15T18:49:29.838Z **lease_created** lease created: lease-9 on node-9
- 2026-06-15T18:49:29.838Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T18:49:34.882Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-done
- 2026-06-15T18:49:34.883Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-verify
- 2026-06-15T18:49:34.883Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T18:49:39.760Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T18:49:39.760Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T18:49:45.572Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:49:45.572Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:49:45.573Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:49:45.573Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:49:45.574Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:49:45.574Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-done
- 2026-06-15T18:49:45.574Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-verify
- 2026-06-15T18:49:45.575Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T18:49:53.364Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:49:53.365Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:49:53.365Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:49:53.365Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:49:53.366Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:49:53.366Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-verify
- 2026-06-15T18:49:53.367Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T18:49:59.334Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:49:59.334Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:49:59.334Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:49:59.335Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:49:59.335Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:49:59.335Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T18:50:06.647Z **lease_released** lease released: lease-9, reason=task_started
- 2026-06-15T18:50:06.647Z **node_status_changed** node status: node-9 running -> ready
- 2026-06-15T18:50:06.647Z **task_status_changed** task status: task-1 active -> pending
- 2026-06-15T18:50:06.648Z **task_created** task created: task-2 Final wrap-up
- 2026-06-15T18:50:06.648Z **map_created** map created: map-2 Final wrap-up
- 2026-06-15T18:50:06.648Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final
- 2026-06-15T18:50:06.649Z **node_status_changed** node status: node-10 pending -> ready
- 2026-06-15T18:50:06.649Z **snapshot_updated** snapshot updated: maps=2 nodes=10
- 2026-06-15T18:50:09.570Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-final
- 2026-06-15T18:50:09.571Z **snapshot_updated** snapshot updated: maps=2 nodes=10
- 2026-06-15T18:50:13.927Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-final
- 2026-06-15T18:50:13.927Z **snapshot_updated** snapshot updated: maps=2 nodes=10
- 2026-06-15T18:50:16.214Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-final
- 2026-06-15T18:50:16.215Z **snapshot_updated** snapshot updated: maps=2 nodes=10
- 2026-06-15T18:50:21.144Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final
- 2026-06-15T18:50:21.144Z **snapshot_updated** snapshot updated: maps=2 nodes=10
- 2026-06-15T18:50:26.708Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final
- 2026-06-15T18:50:26.709Z **snapshot_updated** snapshot updated: maps=2 nodes=10
- 2026-06-15T18:50:29.440Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final
- 2026-06-15T18:50:29.440Z **snapshot_updated** snapshot updated: maps=2 nodes=10
- 2026-06-15T18:50:37.776Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final
- 2026-06-15T18:50:37.776Z **snapshot_updated** snapshot updated: maps=2 nodes=10
- 2026-06-15T18:50:40.987Z **task_status_changed** task status: task-2 active -> pending
- 2026-06-15T18:50:40.988Z **task_status_changed** task status: task-1 pending -> active
- 2026-06-15T18:50:40.988Z **task_routed** task routed: task-2 -> task-1
- 2026-06-15T18:50:40.989Z **snapshot_updated** snapshot updated: maps=2 nodes=10
- 2026-06-15T18:50:43.198Z **node_status_changed** node status: node-11 pending -> ready
- 2026-06-15T18:50:43.199Z **node_status_changed** node status: node-11 ready -> running
- 2026-06-15T18:50:43.199Z **lease_created** lease created: lease-10 on node-11
- 2026-06-15T18:50:43.199Z **snapshot_updated** snapshot updated: maps=2 nodes=11
- 2026-06-15T18:50:46.628Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:50:46.628Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:50:46.628Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:50:46.629Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:50:46.629Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:50:46.629Z **snapshot_updated** snapshot updated: maps=2 nodes=11
- 2026-06-15T18:50:53.175Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-task1-final
- 2026-06-15T18:50:53.175Z **snapshot_updated** snapshot updated: maps=2 nodes=11
- 2026-06-15T18:50:59.021Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact c-report-exists
- 2026-06-15T18:50:59.021Z **snapshot_updated** snapshot updated: maps=2 nodes=11
- 2026-06-15T18:51:04.505Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:51:04.505Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:51:04.506Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:51:04.506Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:51:04.506Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:51:04.507Z **snapshot_updated** snapshot updated: maps=2 nodes=11
- 2026-06-15T18:51:09.406Z **cognitive_state_updated** cognitive state updated: problem_ledger.next_best_action next_best_action
- 2026-06-15T18:51:09.407Z **snapshot_updated** snapshot updated: maps=2 nodes=11
- 2026-06-15T18:51:13.671Z **node_result_recorded** node result recorded: node-11 / result-17
- 2026-06-15T18:51:13.671Z **lease_released** lease released: lease-10, reason=result_recorded
- 2026-06-15T18:51:13.672Z **node_status_changed** node status: node-11 running -> completed
- 2026-06-15T18:51:13.672Z **snapshot_updated** snapshot updated: maps=2 nodes=11
- 2026-06-15T18:46:25.309Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T18:46:25.311Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T18:46:30.143Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T18:46:30.145Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T18:46:38.605Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T18:46:38.608Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T18:46:55.089Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T18:46:55.091Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T18:46:58.068Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T18:46:58.070Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T18:47:01.196Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T18:47:01.198Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T18:47:28.140Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T18:47:28.142Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T18:47:37.927Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T18:47:38.053Z **tool:spawn_agent** tool call: spawn_agent (completed)
- 2026-06-15T18:47:43.730Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T18:47:43.846Z **tool:spawn_agent** tool call: spawn_agent (completed)
- 2026-06-15T18:47:50.026Z **tool:wait_agent** tool call: wait_agent (in_progress)
- 2026-06-15T18:48:02.373Z **tool:wait_agent** tool call: wait_agent (completed)
-  **tool:wait** tool call: wait (in_progress)

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
