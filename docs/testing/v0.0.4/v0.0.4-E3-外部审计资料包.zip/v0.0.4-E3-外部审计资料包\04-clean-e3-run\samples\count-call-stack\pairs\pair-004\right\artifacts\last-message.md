已完成分析。输出文件已写入 `W:\app\output.txt`。

**结果摘要：**
- 在日志文件中发现 **646** 条堆栈跟踪记录
- 基于前 3 帧识别出 **318** 个独立调用点
- 分析的堆栈跟踪总数：**3,158,871**
- 前 10 个独立调用点已按频率降序输出，每个调用点显示其前 3 帧

前 5 个调用点分别为：
1. `printStack` → `StringMap::try_emplace` (第 316 行) → `StringMap::insert` — **268,910 次**
2. `printStack` → `MallocAllocator::Allocate` → `StringMapEntryBase::allocateWithKey` — **261,756 次**
3. `printStack` → `StringRef::strLen` → `StringRef::StringRef` — **245,160 次**
4. `printStack` → `CommandLineParser::addOption` → `Option::addArgument` — **200,874 次**
5. `printStack` → `allocate_buffer` → `MallocAllocator::Allocate` — **195,008 次**