Here's the completed work and results:

## Investigation phase

Scanned all **3 log files** in `/app/logs`:

| File | ERROR | WARNING | INFO |
|------|-------|---------|------|
| `app1.log` | 2 | 1 | 2 |
| `app2.log` | 1 | 1 | 3 |
| `db.log` | 1 | 1 | 3 |
| **Total** | **4** | **3** | **8** |

Counts were verified independently for app logs and db logs using `Select-String -SimpleMatch`, with no false positives or missed matches.

## Implementation phase

Created **`/app/summary.csv`** with the required format:

```csv
severity,count
ERROR,4
WARNING,3
INFO,8
```

## Validation phase

- The CSV is valid with exactly 4 lines (1 header + 3 data rows).
- Every `.log` file in the logs directory was counted (no files missed).
- Checked per-file contents to confirm each line matched its severity keyword correctly.

**All done — summary.csv is ready at `W:\app\summary.csv`.**