﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-002\left\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-002\left\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-002\left\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 10
- edges: 13
- agents: 2
- collab tool calls: 17
- map runtime events: 195
- output contracts: 2
- fact sources: 3
- accepted results: 7
- questioned/invalid results: 4
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: False
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: final_artifact_hash_missing
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=2 |  |
| required_fact_source_missing | True | at least one fact source | factSources=3 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=22, resultWithClaimEvidence=11 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=22, validityTransitions=13 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | False | each final artifact path resolves to a SHA-256 hash | missingHash=1 | task:task-1\|artifact:W:/app/summary.csv |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 2 |
| factSourceCount | 3 |
| activeFactCount | 0 |
| resultCount | 22 |
| acceptedResultCount | 7 |
| questionedOrInvalidResultCount | 4 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 11 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 13 |
| cognitiveStateUpdateCount | 25 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 1 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Scan log files and count severity lines | Scan all .log files in /app/logs, count lines containing ERROR, WARNING, and INFO, and write a summary CSV to /app/summary.csv | 2 | 3 | 0 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-2 | implement_solution | Write summary.csv | blocked | 0 | 1 | 0 | 1 | 0 | 0 |
| node-9 | smoke_test | Validate summary.csv content and format | blocked | 0 | 3 | 1 | 0 | 2 | 0 |
| node-5 | inspect_code_context | Inspect logs - db logs | completed | 1 | 2 | 2 | 0 | 0 | 0 |
| node-4 | inspect_code_context | Inspect logs - app logs | completed | 1 | 5 | 2 | 0 | 0 | 0 |
| node-6 | implement_solution | Write summary CSV | blocked | 0 | 1 | 0 | 1 | 0 | 0 |
| node-3 | implement_solution | Write summary.csv via subagent | blocked | 0 | 1 | 0 | 1 | 0 | 0 |
| node-1 | inspect_code_context | Discover log files and count lines | completed | 0 | 4 | 1 | 0 | 1 | 0 |
| node-7 | implement_solution | Write CSV file via Python | blocked | 0 | 1 | 0 | 1 | 0 | 0 |
| node-10 | final_synthesis | Final summary | blocked | 0 | 1 | 0 | 0 | 0 | 0 |
| node-8 | implement_solution | Write summary.csv with apply_patch | completed | 0 | 3 | 1 | 0 | 0 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:W:/app/summary.csv | task-1 | W:/app/summary.csv |  | result-18, result-21 | oc-1, oc-sp-4 | c-wrote-csv, c-validated2 | artifactRef=W:/app/summary.csv | shell validation command - PASS: summary.csv is valid |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-5 | node-2 | invalid | c-5 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/summary.csv","validatorRef":null} |  | Node was blocked before any edit; no useful result produced |
| result-19 | node-9 | unreviewed |  |  |  |  |
| result-20 | node-9 | unreviewed |  |  |  |  |
| result-21 | node-9 | accepted | c-validated2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/summary.csv","validatorRef":null} | shell validation command - PASS: summary.csv is valid | Test action ran successfully and passed; summary.csv content verified correct |
| result-9 | node-5 | accepted | c-app1, c-app2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/logs/app1.log","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/logs/app2.log","validatorRef":null} |  | Subagent inspected app1.log and app2.log confirming ERROR=3, WARNING=2, INFO=5 combined |
| result-11 | node-5 | accepted | c-db2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/logs/db.log","validatorRef":null} |  | Subagent inspection of db.log complete and verified |
| result-10 | node-4 | accepted | c-db | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/logs/db.log","validatorRef":null} |  | Subagent inspected db.log confirming ERROR=1, WARNING=1, INFO=3 |
| result-12 | node-4 | unreviewed |  |  |  |  |
| result-13 | node-4 | unreviewed |  |  |  |  |
| result-14 | node-4 | unreviewed |  |  |  |  |
| result-15 | node-4 | accepted | c-app-merged | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/logs/app1.log","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/logs/app2.log","validatorRef":null} |  | Subagent completed inspection of app logs; all counts verified |
| result-7 | node-6 | invalid | c-7 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/summary.csv","validatorRef":null} |  | Node blocked; no edit was performed |
| result-6 | node-3 | invalid | c-6 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/summary.csv","validatorRef":null} |  | Blocked due to delegation debt; no edit performed |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | unreviewed |  |  |  |  |
| result-4 | node-1 | accepted | c-1, c-2, c-3, c-4 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/logs/app1.log","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/logs/app2.log","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/logs/db.log","validatorRef":null} |  | Confirmed by manual inspection of file contents and tool-based Select-String counts; totals verified per-file: ERROR=4, WARNING=3, INFO=8 |
| result-8 | node-7 | invalid | c-8 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/summary.csv","validatorRef":null} |  | Blocked by delegation debt |
| result-22 | node-10 | unreviewed |  |  |  |  |
| result-16 | node-8 | unreviewed |  |  |  |  |
| result-17 | node-8 | unreviewed |  |  |  |  |
| result-18 | node-8 | accepted | c-wrote-csv | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/summary.csv","validatorRef":null} |  | summary.csv created with correct content and verified via Get-Content |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-1 | node-3 |
| node-1 | node-4 |
| node-1 | node-5 |
| node-1 | node-6 |
| node-1 | node-7 |
| node-1 | node-8 |
| node-8 | node-9 |
| node-4 | node-9 |
| node-5 | node-9 |
| node-4 | node-10 |
| node-5 | node-10 |
| node-8 | node-10 |

## Timeline

- 2026-06-15T19:08:18.030Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T19:08:21.392Z **task_created** task created: task-1 Scan log files and count severity lines
- 2026-06-15T19:08:21.393Z **map_created** map created: map-1 Scan log files and count severity lines
- 2026-06-15T19:08:21.393Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T19:08:21.394Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T19:08:21.394Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T19:08:21.395Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:08:23.928Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T19:08:23.928Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:08:23.930Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:08:23.930Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:08:23.931Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:08:27.562Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-user-request
- 2026-06-15T19:08:27.563Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:08:35.694Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T19:08:35.695Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T19:08:35.696Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:08:41.461Z **node_result_recorded** node result recorded: node-1 / result-2 action=search
- 2026-06-15T19:08:41.461Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T19:08:41.462Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:08:47.233Z **node_result_recorded** node result recorded: node-1 / result-3 action=read
- 2026-06-15T19:08:47.233Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-3 tags=tool_success
- 2026-06-15T19:08:47.234Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:08:50.852Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-log-scan
- 2026-06-15T19:08:50.853Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:08:52.521Z **tool_action_blocked** tool action blocked: node-1 edit via apply_patch
- 2026-06-15T19:08:52.522Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:08:55.170Z **node_result_recorded** node result recorded: node-1 / result-4
- 2026-06-15T19:08:55.170Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T19:08:55.171Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T19:08:55.171Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T19:08:55.171Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T19:08:55.172Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T19:08:55.172Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:09:00.281Z **result_validity_changed** result validity: result-4 -> accepted
- 2026-06-15T19:09:00.281Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:09:16.179Z **node_result_recorded** node result recorded: node-2 / result-5
- 2026-06-15T19:09:16.179Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T19:09:16.180Z **node_status_changed** node status: node-2 running -> blocked
- 2026-06-15T19:09:16.180Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:09:18.325Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T19:09:18.326Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:09:25.077Z **result_validity_changed** result validity: result-5 -> unreviewed
- 2026-06-15T19:09:25.077Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:09:29.571Z **result_validity_changed** result validity: result-5 -> invalid
- 2026-06-15T19:09:29.571Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:09:35.804Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T19:09:35.804Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T19:09:35.804Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:09:43.452Z **node_result_recorded** node result recorded: node-3 / result-6
- 2026-06-15T19:09:43.452Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T19:09:43.453Z **node_status_changed** node status: node-3 running -> blocked
- 2026-06-15T19:09:43.453Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:09:45.950Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T19:09:45.951Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:09:47.893Z **node_status_changed** node status: node-5 pending -> ready
- 2026-06-15T19:09:47.894Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:09:50.139Z **result_validity_changed** result validity: result-6 -> invalid
- 2026-06-15T19:09:50.139Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:09:59.781Z **cognitive_state_updated** cognitive state updated: problem_ledger.next_best_action next_best_action
- 2026-06-15T19:09:59.781Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:10:04.211Z **cognitive_state_updated** cognitive state updated: problem_ledger.next_best_action next_best_action
- 2026-06-15T19:10:04.211Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:10:15.577Z **node_status_changed** node status: node-6 pending -> ready
- 2026-06-15T19:10:15.577Z **node_status_changed** node status: node-6 ready -> running
- 2026-06-15T19:10:15.578Z **lease_created** lease created: lease-4 on node-6
- 2026-06-15T19:10:15.578Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:10:19.730Z **cognitive_state_updated** cognitive state updated: result_adoption result-4
- 2026-06-15T19:10:19.731Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:10:32.354Z **cognitive_state_updated** cognitive state updated: problem_ledger.next_best_action next_best_action
- 2026-06-15T19:10:32.355Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:10:42.183Z **node_result_recorded** node result recorded: node-6 / result-7
- 2026-06-15T19:10:42.183Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T19:10:42.184Z **node_status_changed** node status: node-6 running -> blocked
- 2026-06-15T19:10:42.184Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:10:47.972Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-sp-4
- 2026-06-15T19:10:47.972Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:10:51.899Z **result_validity_changed** result validity: result-7 -> invalid
- 2026-06-15T19:10:51.899Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:10:58.331Z **node_status_changed** node status: node-7 pending -> ready
- 2026-06-15T19:10:58.332Z **node_status_changed** node status: node-7 ready -> running
- 2026-06-15T19:10:58.332Z **lease_created** lease created: lease-5 on node-7
- 2026-06-15T19:10:58.333Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:11:10.286Z **node_result_recorded** node result recorded: node-7 / result-8
- 2026-06-15T19:11:10.286Z **lease_released** lease released: lease-5, reason=result_recorded
- 2026-06-15T19:11:10.286Z **node_status_changed** node status: node-7 running -> blocked
- 2026-06-15T19:11:10.287Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:11:12.512Z **result_validity_changed** result validity: result-8 -> invalid
- 2026-06-15T19:11:12.512Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:11:14.341Z **node_status_changed** node status: node-8 pending -> ready
- 2026-06-15T19:11:14.341Z **node_status_changed** node status: node-8 ready -> running
- 2026-06-15T19:11:14.341Z **lease_created** lease created: lease-6 on node-8
- 2026-06-15T19:11:14.342Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:21.716Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source subagent-plan-node-4
- 2026-06-15T19:11:21.717Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:32.904Z **cognitive_state_updated** cognitive state updated: subagent_plan.recorded subagent-plan-1
- 2026-06-15T19:11:32.904Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:34.853Z **cognitive_state_updated** cognitive state updated: subagent_plan.recorded subagent-plan-2
- 2026-06-15T19:11:34.853Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:37.140Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T19:11:37.140Z **lease_created** lease created: lease-7 on node-4
- 2026-06-15T19:11:37.140Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:37.264Z **lease_attached** agent attached: /root/inspect_app_logs -> node-4
- 2026-06-15T19:11:37.265Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:37.267Z **node_status_changed** node status: node-5 ready -> running
- 2026-06-15T19:11:37.268Z **lease_created** lease created: lease-8 on node-5
- 2026-06-15T19:11:37.268Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:37.436Z **lease_attached** agent attached: /root/inspect_db_logs -> node-5
- 2026-06-15T19:11:37.437Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:41.997Z **node_result_recorded** node result recorded: node-5 / result-9 action=read
- 2026-06-15T19:11:41.998Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:42.012Z **node_result_recorded** node result recorded: node-4 / result-10 action=read
- 2026-06-15T19:11:42.012Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:46.330Z **node_result_recorded** node result recorded: node-5 / result-11
- 2026-06-15T19:11:46.330Z **lease_released** lease released: lease-8, reason=result_recorded
- 2026-06-15T19:11:46.331Z **node_status_changed** node status: node-5 running -> completed
- 2026-06-15T19:11:46.331Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:48.070Z **node_result_recorded** node result recorded: node-4 / result-12 action=read
- 2026-06-15T19:11:48.070Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:52.787Z **node_result_recorded** node result recorded: node-4 / result-13 action=read
- 2026-06-15T19:11:52.788Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:52.790Z **node_result_recorded** node result recorded: node-4 / result-14 action=read
- 2026-06-15T19:11:52.790Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:11:56.584Z **node_result_recorded** node result recorded: node-4 / result-15
- 2026-06-15T19:11:56.584Z **lease_released** lease released: lease-7, reason=result_recorded
- 2026-06-15T19:11:56.585Z **node_status_changed** node status: node-4 running -> completed
- 2026-06-15T19:11:56.585Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:12:06.704Z **result_validity_changed** result validity: result-9 -> accepted
- 2026-06-15T19:12:06.704Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:12:08.880Z **result_validity_changed** result validity: result-10 -> accepted
- 2026-06-15T19:12:08.881Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:12:14.855Z **result_validity_changed** result validity: result-11 -> accepted
- 2026-06-15T19:12:14.856Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:12:19.429Z **result_validity_changed** result validity: result-15 -> accepted
- 2026-06-15T19:12:19.429Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:12:20.982Z **node_result_recorded** node result recorded: node-8 / result-16 action=edit
- 2026-06-15T19:12:20.983Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-16 tags=tool_success
- 2026-06-15T19:12:20.983Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:12:25.959Z **node_result_recorded** node result recorded: node-8 / result-17 action=read
- 2026-06-15T19:12:25.960Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-17 tags=tool_success
- 2026-06-15T19:12:25.961Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:12:28.448Z **node_result_recorded** node result recorded: node-8 / result-18
- 2026-06-15T19:12:28.449Z **lease_released** lease released: lease-6, reason=result_recorded
- 2026-06-15T19:12:28.449Z **node_status_changed** node status: node-8 running -> completed
- 2026-06-15T19:12:28.449Z **node_status_changed** node status: node-9 pending -> ready
- 2026-06-15T19:12:28.450Z **node_status_changed** node status: node-9 ready -> running
- 2026-06-15T19:12:28.450Z **lease_created** lease created: lease-9 on node-9
- 2026-06-15T19:12:28.450Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:12:35.266Z **result_validity_changed** result validity: result-18 -> accepted
- 2026-06-15T19:12:35.266Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:12:41.480Z **node_result_recorded** node result recorded: node-9 / result-19 action=read
- 2026-06-15T19:12:41.481Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-19 tags=tool_success
- 2026-06-15T19:12:41.481Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:12:45.482Z **tool_action_blocked** tool action blocked: node-9 unknown via bind_node
- 2026-06-15T19:12:45.483Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:12:51.370Z **node_result_recorded** node result recorded: node-9 / result-20 action=read
- 2026-06-15T19:12:51.370Z **taskspace_trace_event_recorded** trace event: trace-7 result=result-20 tags=tool_success
- 2026-06-15T19:12:51.371Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:13:00.434Z **tool_action_blocked** tool action blocked: node-9 edit via shell_command
- 2026-06-15T19:13:00.435Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:13:02.662Z **cognitive_state_updated** cognitive state updated: result_adoption result-18
- 2026-06-15T19:13:02.663Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:13:06.919Z **node_result_recorded** node result recorded: node-9 / result-21
- 2026-06-15T19:13:06.920Z **lease_released** lease released: lease-9, reason=result_recorded
- 2026-06-15T19:13:06.920Z **node_status_changed** node status: node-9 running -> blocked
- 2026-06-15T19:13:06.920Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:13:08.945Z **node_status_changed** node status: node-10 pending -> ready
- 2026-06-15T19:13:08.945Z **node_status_changed** node status: node-10 ready -> running
- 2026-06-15T19:13:08.945Z **lease_created** lease created: lease-10 on node-10
- 2026-06-15T19:13:08.946Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:13:11.875Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T19:13:11.875Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:13:14.133Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:13:14.134Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:13:14.134Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:13:18.380Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:13:18.380Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:13:18.381Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:13:22.386Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:13:22.386Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:13:22.387Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:13:27.114Z **result_validity_changed** result validity: result-21 -> unreviewed
- 2026-06-15T19:13:27.114Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:13:31.282Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:13:31.282Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:13:31.283Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:13:35.964Z **result_validity_changed** result validity: result-21 -> accepted
- 2026-06-15T19:13:35.964Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:13:39.829Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:13:39.829Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:13:39.830Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:13:41.848Z **node_result_recorded** node result recorded: node-10 / result-22
- 2026-06-15T19:13:41.849Z **lease_released** lease released: lease-10, reason=result_recorded
- 2026-06-15T19:13:41.849Z **node_status_changed** node status: node-10 running -> blocked
- 2026-06-15T19:13:41.849Z **snapshot_updated** snapshot updated: maps=1 nodes=10
- 2026-06-15T19:09:20.691Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:09:20.692Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:09:27.069Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:09:27.070Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:09:31.387Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:09:31.389Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:09:52.170Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:09:52.171Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:10:01.371Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:10:01.373Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:10:34.255Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:10:34.257Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:10:49.552Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:10:49.554Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:10:53.481Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:10:53.483Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:11:23.504Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:11:23.505Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:11:37.138Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:11:37.138Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:11:37.267Z **tool:spawn_agent** tool call: spawn_agent (completed)
- 2026-06-15T19:11:37.439Z **tool:spawn_agent** tool call: spawn_agent (completed)
- 2026-06-15T19:11:38.607Z **tool:wait_agent** tool call: wait_agent (in_progress)
- 2026-06-15T19:11:46.332Z **tool:wait_agent** tool call: wait_agent (completed)
- 2026-06-15T19:11:47.494Z **tool:wait_agent** tool call: wait_agent (in_progress)
- 2026-06-15T19:11:56.585Z **tool:wait_agent** tool call: wait_agent (completed)
- 2026-06-15T19:11:58.302Z **tool:close_agent** tool call: close_agent (in_progress)
- 2026-06-15T19:11:58.303Z **tool:close_agent** tool call: close_agent (in_progress)
- 2026-06-15T19:11:58.314Z **tool:close_agent** tool call: close_agent (completed)
- 2026-06-15T19:11:58.328Z **tool:close_agent** tool call: close_agent (completed)
-  **tool:wait** tool call: wait (in_progress)
-  **tool:wait** tool call: wait (in_progress)

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
