The analysis is complete. Here's a summary of the results:

**Output file written to `W:\app\output.txt`**

| Metric | Value |
|---|---|
| Total stack trace entries found in file | 646 |
| Sum of all occurrence counts (total traces analyzed) | 3,158,871 |
| Unique call sites based on top 3 frames | 318 |
| Top 10 most common | Written to output.txt |

**Top 3 most frequent call sites:**

1. **Count: 268,910** — `StringMap::try_emplace` → `StringMap::insert` (via `printStack`)
2. **Count: 261,756** — `MallocAllocator::Allocate` → `StringMapEntryBase::allocateWithKey`
3. **Count: 245,160** — `StringRef::strLen` → `StringRef::StringRef(char const*)`

The parsing logic:
- Each trace entry starts with a count line (integer)
- Stack frames follow (tab-prefixed lines)
- The top 3 frames (first 3 frame lines) define the unique call site signature
- Frames with `\t in ` prefix are cleaned to remove the tab and "in " for clean formatting