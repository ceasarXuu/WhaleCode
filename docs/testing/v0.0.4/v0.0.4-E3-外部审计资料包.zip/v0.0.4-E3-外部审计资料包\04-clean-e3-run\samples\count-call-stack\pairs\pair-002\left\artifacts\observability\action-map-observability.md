﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\left\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\left\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\left\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 6
- edges: 5
- agents: 0
- collab tool calls: 0
- map runtime events: 173
- output contracts: 2
- fact sources: 1
- accepted results: 4
- questioned/invalid results: 1
- final artifacts: 2
- cognitive structural gate: True
- cognitive hard gate: False
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: final_artifact_hash_missing
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=2 |  |
| required_fact_source_missing | True | at least one fact source | factSources=1 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=27, resultWithClaimEvidence=5 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=27, validityTransitions=5 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | False | each final artifact path resolves to a SHA-256 hash | missingHash=2 | task:task-1\|artifact:W:\app\output.txt, task:task-1\|artifact:W:\app\analyze.py |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 2 |
| factSourceCount | 1 |
| activeFactCount | 0 |
| resultCount | 27 |
| acceptedResultCount | 4 |
| questionedOrInvalidResultCount | 1 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 5 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 5 |
| cognitiveStateUpdateCount | 22 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 2 |
| finalArtifactMissingHashCount | 2 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Profiling stack trace analysis | Analyze profiling stack traces from log files, identify unique call sites based on top 3 frames, output top 10 stats to output.txt | 2 | 1 | 0 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-5 | implement_solution | Execute analysis script | completed | 0 | 6 | 1 | 0 | 1 | 0 |
| node-6 | final_synthesis | Final synthesis of stack trace analysis | blocked | 0 | 1 | 0 | 0 | 0 | 0 |
| node-4 | implement_solution | Write and execute analysis script | completed | 0 | 11 | 1 | 0 | 3 | 0 |
| node-1 | inspect_code_context | Inspect log files and code context | completed | 0 | 5 | 1 | 0 | 1 | 0 |
| node-3 | inspect_code_context | Debug stack trace parsing format | completed | 0 | 2 | 1 | 0 | 2 | 0 |
| node-2 | implement_solution | Analyze stack traces and produce output.txt | blocked | 0 | 2 | 0 | 1 | 2 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:W:\app\output.txt | task-1 | W:\app\output.txt |  | result-26 | oc-1, oc-2 | cl-6, cl-7 | artifactRef=W:\app\output.txt |  |  |  |
| task:task-1\|artifact:W:\app\analyze.py | task-1 | W:\app\analyze.py |  | result-20 | oc-1, oc-2 | cl-5 | artifactRef=W:\app\log_extracted\log.stack |  |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-21 | node-5 | unreviewed |  |  |  |  |
| result-22 | node-5 | unreviewed |  |  |  |  |
| result-23 | node-5 | unreviewed |  |  |  |  |
| result-24 | node-5 | unreviewed |  |  |  |  |
| result-25 | node-5 | unreviewed |  |  |  |  |
| result-26 | node-5 | accepted | cl-6, cl-7 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\output.txt","validatorRef":null} |  | Script produced correct output with 646 traces analyzed, 317 unique call sites, top 10 sorted by frequency descending. Output matches required format. |
| result-27 | node-6 | unreviewed |  |  |  |  |
| result-10 | node-4 | unreviewed |  |  |  |  |
| result-11 | node-4 | unreviewed |  |  |  |  |
| result-12 | node-4 | unreviewed |  |  |  |  |
| result-13 | node-4 | unreviewed |  |  |  |  |
| result-14 | node-4 | unreviewed |  |  |  |  |
| result-15 | node-4 | unreviewed |  |  |  |  |
| result-16 | node-4 | unreviewed |  |  |  |  |
| result-17 | node-4 | unreviewed |  |  |  |  |
| result-18 | node-4 | unreviewed |  |  |  |  |
| result-19 | node-4 | unreviewed |  |  |  |  |
| result-20 | node-4 | accepted | cl-5 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\log_extracted\\log.stack","validatorRef":null} |  | Fixed parsing bug: line format is TAB+SPACE+"in " not TAB+"in ". Script ready to execute. |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | unreviewed |  |  |  |  |
| result-4 | node-1 | unreviewed |  |  |  |  |
| result-5 | node-1 | accepted | cl-1, cl-2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\log_extracted\\log.stack","validatorRef":null} |  | Inspected log format and confirmed trace structure: count lines followed by "\t in " frame lines. Fragmented continuation lines exist and should be filtered. |
| result-8 | node-3 | unreviewed |  |  |  |  |
| result-9 | node-3 | accepted | cl-4 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\log_extracted\\log.stack","validatorRef":null} |  | Confirmed file format: count lines are numbers, frame lines have tab + 'in ' prefix. |
| result-6 | node-2 | unreviewed |  |  |  |  |
| result-7 | node-2 | questioned | cl-3 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\output.txt","validatorRef":null} |  | Analysis produced 0 stack traces - parsing logic likely wrong or file format differs from assumptions. |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-1 | node-3 |
| node-3 | node-4 |
| node-4 | node-5 |
| node-5 | node-6 |

## Timeline

- 2026-06-15T19:48:20.597Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T19:48:24.389Z **task_created** task created: task-1 Profiling stack trace analysis
- 2026-06-15T19:48:24.389Z **map_created** map created: map-1 Profiling stack trace analysis
- 2026-06-15T19:48:24.390Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:48:24.390Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:48:24.391Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:48:24.395Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T19:48:24.396Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:48:32.013Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T19:48:32.013Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:48:32.014Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-2
- 2026-06-15T19:48:32.015Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:48:32.016Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T19:48:32.016Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:48:34.101Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:48:34.102Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:48:34.102Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:48:34.102Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:48:37.673Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T19:48:37.674Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T19:48:37.674Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:48:43.329Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T19:48:43.330Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T19:48:43.330Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:48:48.707Z **node_result_recorded** node result recorded: node-1 / result-2 action=read
- 2026-06-15T19:48:48.707Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T19:48:48.708Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:48:53.318Z **node_result_recorded** node result recorded: node-1 / result-3 action=read
- 2026-06-15T19:48:53.319Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-3 tags=tool_success
- 2026-06-15T19:48:53.319Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:49:02.230Z **node_result_recorded** node result recorded: node-1 / result-4 action=read
- 2026-06-15T19:49:02.231Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-4 tags=tool_success
- 2026-06-15T19:49:02.231Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:49:19.838Z **tool_action_blocked** tool action blocked: node-1 edit via shell_command
- 2026-06-15T19:49:19.840Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:49:24.046Z **node_result_recorded** node result recorded: node-1 / result-5
- 2026-06-15T19:49:24.047Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T19:49:24.047Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T19:49:24.047Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T19:49:24.048Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T19:49:24.048Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T19:49:24.048Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:49:33.049Z **result_validity_changed** result validity: result-5 -> accepted
- 2026-06-15T19:49:33.050Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:49:40.039Z **node_result_recorded** node result recorded: node-2 / result-6 action=edit
- 2026-06-15T19:49:40.039Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-6 tags=tool_success
- 2026-06-15T19:49:40.040Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:49:42.801Z **tool_action_blocked** tool action blocked: node-2 unknown via shell_command
- 2026-06-15T19:49:42.802Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:49:48.806Z **tool_action_blocked** tool action blocked: node-2 unknown via shell_command
- 2026-06-15T19:49:48.806Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:49:52.702Z **node_result_recorded** node result recorded: node-2 / result-7
- 2026-06-15T19:49:52.702Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T19:49:52.703Z **node_status_changed** node status: node-2 running -> blocked
- 2026-06-15T19:49:52.703Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:49:54.942Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T19:49:54.942Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T19:49:54.942Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T19:49:54.943Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:49:59.688Z **result_validity_changed** result validity: result-7 -> questioned
- 2026-06-15T19:49:59.689Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:50:04.390Z **node_result_recorded** node result recorded: node-3 / result-8 action=read
- 2026-06-15T19:50:04.391Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-8 tags=tool_success
- 2026-06-15T19:50:04.391Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:50:10.201Z **tool_action_blocked** tool action blocked: node-3 edit via shell_command
- 2026-06-15T19:50:10.202Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:50:14.210Z **tool_action_blocked** tool action blocked: node-3 unknown via shell_command
- 2026-06-15T19:50:14.211Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:50:21.169Z **node_result_recorded** node result recorded: node-3 / result-9
- 2026-06-15T19:50:21.169Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T19:50:21.169Z **node_status_changed** node status: node-3 running -> completed
- 2026-06-15T19:50:21.170Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T19:50:21.170Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T19:50:21.170Z **lease_created** lease created: lease-4 on node-4
- 2026-06-15T19:50:21.171Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:50:23.901Z **result_validity_changed** result validity: result-9 -> accepted
- 2026-06-15T19:50:23.901Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:50:29.676Z **node_result_recorded** node result recorded: node-4 / result-10 action=edit
- 2026-06-15T19:50:29.677Z **taskspace_trace_event_recorded** trace event: trace-7 result=result-10 tags=tool_success
- 2026-06-15T19:50:29.677Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:50:31.868Z **tool_action_blocked** tool action blocked: node-4 unknown via shell_command
- 2026-06-15T19:50:31.868Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:50:37.807Z **node_result_recorded** node result recorded: node-4 / result-11 action=edit
- 2026-06-15T19:50:37.807Z **taskspace_trace_event_recorded** trace event: trace-8 result=result-11 tags=tool_success
- 2026-06-15T19:50:37.808Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:50:40.735Z **tool_action_blocked** tool action blocked: node-4 unknown via shell_command
- 2026-06-15T19:50:40.735Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:50:50.456Z **node_result_recorded** node result recorded: node-4 / result-12 action=edit
- 2026-06-15T19:50:50.457Z **taskspace_trace_event_recorded** trace event: trace-9 result=result-12 tags=tool_success
- 2026-06-15T19:50:50.457Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:51:00.330Z **node_result_recorded** node result recorded: node-4 / result-13 action=edit
- 2026-06-15T19:51:00.330Z **taskspace_trace_event_recorded** trace event: trace-10 result=result-13 tags=tool_failure
- 2026-06-15T19:51:00.331Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:51:04.092Z **node_result_recorded** node result recorded: node-4 / result-14 action=edit
- 2026-06-15T19:51:04.093Z **taskspace_trace_event_recorded** trace event: trace-11 result=result-14 tags=tool_success
- 2026-06-15T19:51:04.093Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:51:05.674Z **tool_action_blocked** tool action blocked: node-4 unknown via shell_command
- 2026-06-15T19:51:05.675Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:51:11.772Z **node_result_recorded** node result recorded: node-4 / result-15 action=edit
- 2026-06-15T19:51:11.773Z **taskspace_trace_event_recorded** trace event: trace-12 result=result-15 tags=tool_failure
- 2026-06-15T19:51:11.773Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:51:17.501Z **node_result_recorded** node result recorded: node-4 / result-16 action=edit
- 2026-06-15T19:51:17.502Z **taskspace_trace_event_recorded** trace event: trace-13 result=result-16 tags=tool_success
- 2026-06-15T19:51:17.502Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:51:23.436Z **node_result_recorded** node result recorded: node-4 / result-17 action=edit
- 2026-06-15T19:51:23.436Z **taskspace_trace_event_recorded** trace event: trace-14 result=result-17 tags=tool_failure
- 2026-06-15T19:51:23.437Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:51:29.056Z **node_result_recorded** node result recorded: node-4 / result-18 action=edit
- 2026-06-15T19:51:29.057Z **taskspace_trace_event_recorded** trace event: trace-15 result=result-18 tags=tool_failure
- 2026-06-15T19:51:29.057Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:51:31.133Z **node_result_recorded** node result recorded: node-4 / result-19 action=edit
- 2026-06-15T19:51:31.133Z **taskspace_trace_event_recorded** trace event: trace-16 result=result-19 tags=tool_success
- 2026-06-15T19:51:31.134Z **maintenance_barrier_raised** maintenance barrier raised: node-4 10/10
- 2026-06-15T19:51:31.134Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:51:39.235Z **node_result_recorded** node result recorded: node-4 / result-20
- 2026-06-15T19:51:39.235Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T19:51:39.235Z **node_status_changed** node status: node-4 running -> completed
- 2026-06-15T19:51:39.236Z **maintenance_barrier_cleared** maintenance barrier cleared: node-4, reason=node_lifecycle_recorded
- 2026-06-15T19:51:39.236Z **node_status_changed** node status: node-5 pending -> ready
- 2026-06-15T19:51:39.236Z **node_status_changed** node status: node-5 ready -> running
- 2026-06-15T19:51:39.237Z **lease_created** lease created: lease-5 on node-5
- 2026-06-15T19:51:39.237Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:51:45.206Z **result_validity_changed** result validity: result-20 -> accepted
- 2026-06-15T19:51:45.206Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:51:46.936Z **tool_action_blocked** tool action blocked: node-5 unknown via shell_command
- 2026-06-15T19:51:46.936Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:51:52.801Z **node_result_recorded** node result recorded: node-5 / result-21 action=read
- 2026-06-15T19:51:52.802Z **taskspace_trace_event_recorded** trace event: trace-17 result=result-21 tags=tool_failure
- 2026-06-15T19:51:52.802Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:51:57.630Z **node_result_recorded** node result recorded: node-5 / result-22 action=read
- 2026-06-15T19:51:57.630Z **taskspace_trace_event_recorded** trace event: trace-18 result=result-22 tags=tool_failure
- 2026-06-15T19:51:57.631Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:52:02.937Z **node_result_recorded** node result recorded: node-5 / result-23 action=read
- 2026-06-15T19:52:02.937Z **taskspace_trace_event_recorded** trace event: trace-19 result=result-23 tags=tool_success
- 2026-06-15T19:52:02.938Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:52:10.986Z **node_result_recorded** node result recorded: node-5 / result-24 action=edit
- 2026-06-15T19:52:10.987Z **taskspace_trace_event_recorded** trace event: trace-20 result=result-24 tags=tool_success
- 2026-06-15T19:52:10.987Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:52:16.206Z **node_result_recorded** node result recorded: node-5 / result-25 action=read
- 2026-06-15T19:52:16.207Z **taskspace_trace_event_recorded** trace event: trace-21 result=result-25 tags=tool_success
- 2026-06-15T19:52:16.207Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:52:21.603Z **node_result_recorded** node result recorded: node-5 / result-26
- 2026-06-15T19:52:21.604Z **lease_released** lease released: lease-5, reason=result_recorded
- 2026-06-15T19:52:21.604Z **node_status_changed** node status: node-5 running -> completed
- 2026-06-15T19:52:21.604Z **node_status_changed** node status: node-6 pending -> ready
- 2026-06-15T19:52:21.605Z **node_status_changed** node status: node-6 ready -> running
- 2026-06-15T19:52:21.605Z **lease_created** lease created: lease-6 on node-6
- 2026-06-15T19:52:21.605Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:52:25.084Z **result_validity_changed** result validity: result-26 -> accepted
- 2026-06-15T19:52:25.084Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:52:27.910Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:52:27.910Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:52:27.910Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:52:27.911Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:52:30.776Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T19:52:30.776Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-26
- 2026-06-15T19:52:30.777Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:52:45.338Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:52:45.339Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:52:45.339Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:52:45.339Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:52:50.990Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-original-1
- 2026-06-15T19:52:50.992Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-original-2
- 2026-06-15T19:52:50.993Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-original-3
- 2026-06-15T19:52:50.994Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:52:53.039Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:52:53.039Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:52:58.943Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-waive-all
- 2026-06-15T19:52:58.943Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:53:01.162Z **node_result_recorded** node result recorded: node-6 / result-27
- 2026-06-15T19:53:01.163Z **lease_released** lease released: lease-6, reason=result_recorded
- 2026-06-15T19:53:01.163Z **node_status_changed** node status: node-6 running -> blocked
- 2026-06-15T19:53:01.163Z **snapshot_updated** snapshot updated: maps=1 nodes=6

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
