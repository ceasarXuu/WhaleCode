Done. Here's the summary:

**Scan results from 3 log files** (`app1.log`, `app2.log`, `db.log`):

| Severity | Count |
|----------|-------|
| ERROR    | 4     |
| WARNING  | 3     |
| INFO     | 8     |

The results have been written to `W:\app\summary.csv` in proper CSV format with a header row and one row per severity level.