Done! The report has been created at `W:\app\report.txt` with the following contents:

**Summary of `/app/access_log`:**

| Metric | Value |
|---|---|
| **Total requests** | 2000 |
| **Unique IP addresses** | 273 |
| **Top 1 URL** | `/order-confirmation` (54 requests) |
| **Top 2 URL** | `/product/456` (53 requests) |
| **Top 3 URL** | `/about.html` (52 requests) |
| **404 errors** | 89 |

The report file is ready at `W:\app\report.txt` in the exact format requested.