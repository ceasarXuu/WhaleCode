已完成。扫描了 `W:\app\logs` 中的 3 个 `.log` 文件，统计结果如下：

| 严重级别 | 行数 |
|-----------|-------|
| ERROR     | 4     |
| WARNING   | 3     |
| INFO      | 8     |

已将结果写入 `W:\app\summary.csv`，格式为包含标题行的有效 CSV 文件。