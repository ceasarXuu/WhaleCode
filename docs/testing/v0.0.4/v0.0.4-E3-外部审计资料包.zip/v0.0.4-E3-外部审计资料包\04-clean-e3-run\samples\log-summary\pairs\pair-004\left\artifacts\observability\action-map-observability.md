﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-004\left\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-004\left\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-004\left\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 5
- edges: 6
- agents: 2
- collab tool calls: 19
- map runtime events: 162
- output contracts: 4
- fact sources: 2
- accepted results: 4
- questioned/invalid results: 2
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: True
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: none
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=4 |  |
| required_fact_source_missing | True | at least one fact source | factSources=2 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=19, resultWithClaimEvidence=6 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=19, validityTransitions=7 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | True | each final artifact path resolves to a SHA-256 hash | missingHash=0 |  |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 4 |
| factSourceCount | 2 |
| activeFactCount | 1 |
| resultCount | 19 |
| acceptedResultCount | 4 |
| questionedOrInvalidResultCount | 2 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 6 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 7 |
| cognitiveStateUpdateCount | 37 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 0 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Scan log files and count severity levels | Scan all .log files in /app/logs, count ERROR/WARNING/INFO lines, output to /app/summary.csv | 4 | 2 | 1 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-5 | final_synthesis | Final synthesis: log severity summary complete | blocked | 0 | 1 | 0 | 0 | 0 | 0 |
| node-1 | inspect_code_context | Inspect log files and count severity | completed | 0 | 4 | 1 | 0 | 0 | 0 |
| node-2 | implement_solution | Write summary.csv | completed | 0 | 5 | 1 | 2 | 0 | 0 |
| node-4 | inspect_code_context | Inspect db logs (db.log) | completed | 1 | 5 | 1 | 0 | 0 | 0 |
| node-3 | inspect_code_context | Inspect app logs (app1.log, app2.log) | completed | 1 | 4 | 1 | 0 | 0 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:summary.csv | task-1 | summary.csv | 3905149e018ffc57 | result-18 | oc-1, oc-2, oc-3, oc-4 | c-csv-created | artifactRef=W:\app\summary.csv |  |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-19 | node-5 | unreviewed |  |  |  |  |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | unreviewed |  |  |  |  |
| result-4 | node-1 | accepted | c-app-1, c-app-2, c-app-total | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\logs\\app1.log","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\logs\\app2.log","validatorRef":null} |  | All three log files counted and verified. Totals: ERROR=4, WARNING=3, INFO=8. Ready to write summary.csv. |
| result-5 | node-2 | questioned | c-blocked | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"blocker_summary from block_node","validatorRef":null} |  | Blocked by runtime requirement for subagent investigation tracks before CSV can be written |
| result-6 | node-2 | questioned | c-blocked-2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"blocker_summary from block_node","validatorRef":null} |  | Blocked - CSV write prevented by subagent investigation requirement |
| result-16 | node-2 | unreviewed |  |  |  |  |
| result-17 | node-2 | unreviewed |  |  |  |  |
| result-18 | node-2 | accepted | c-csv-created | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\summary.csv","validatorRef":null} |  | CSV file created successfully, contents verified: 4 lines with correct header and data |
| result-8 | node-4 | unreviewed |  |  |  |  |
| result-10 | node-4 | unreviewed |  |  |  |  |
| result-11 | node-4 | unreviewed |  |  |  |  |
| result-12 | node-4 | unreviewed |  |  |  |  |
| result-13 | node-4 | accepted | c-db-1 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\logs\\db.log","validatorRef":null} |  | Subagent confirmed db.log counts: ERROR=1, WARNING=1, INFO=3 using Select-String -SimpleMatch |
| result-7 | node-3 | unreviewed |  |  |  |  |
| result-9 | node-3 | unreviewed |  |  |  |  |
| result-14 | node-3 | unreviewed |  |  |  |  |
| result-15 | node-3 | accepted | c-app-1-total | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\logs\\app1.log","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\logs\\app2.log","validatorRef":null} |  | Subagent confirmed app logs: app1.log ERROR=2/WARNING=1/INFO=2, app2.log ERROR=1/WARNING=1/INFO=3, total ERROR=3/WARNING=2/INFO=5 |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-1 | node-3 |
| node-1 | node-4 |
| node-2 | node-5 |
| node-3 | node-5 |
| node-4 | node-5 |

## Timeline

- 2026-06-15T19:25:09.731Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T19:25:13.357Z **task_created** task created: task-1 Scan log files and count severity levels
- 2026-06-15T19:25:13.357Z **map_created** map created: map-1 Scan log files and count severity levels
- 2026-06-15T19:25:13.357Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:25:13.358Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:25:13.358Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:25:13.359Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T19:25:13.359Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:25:19.250Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T19:25:19.251Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:25:19.252Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-2
- 2026-06-15T19:25:19.253Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:25:19.255Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T19:25:19.255Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:25:19.257Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-2
- 2026-06-15T19:25:19.257Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:25:22.277Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T19:25:22.277Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T19:25:22.278Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:25:28.499Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T19:25:28.500Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T19:25:28.500Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:25:34.096Z **node_result_recorded** node result recorded: node-1 / result-2 action=search
- 2026-06-15T19:25:34.097Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T19:25:34.097Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:25:40.193Z **node_result_recorded** node result recorded: node-1 / result-3 action=search
- 2026-06-15T19:25:40.193Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-3 tags=tool_success
- 2026-06-15T19:25:40.194Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:25:43.248Z **node_result_recorded** node result recorded: node-1 / result-4
- 2026-06-15T19:25:43.249Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T19:25:43.249Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T19:25:43.250Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T19:25:43.250Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T19:25:43.250Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T19:25:43.251Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:25:51.422Z **result_validity_changed** result validity: result-4 -> accepted
- 2026-06-15T19:25:51.422Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:26:11.671Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T19:26:11.673Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:26:11.674Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T19:26:11.674Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:26:22.484Z **node_result_recorded** node result recorded: node-2 / result-5
- 2026-06-15T19:26:22.484Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T19:26:22.484Z **node_status_changed** node status: node-2 running -> blocked
- 2026-06-15T19:26:22.485Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:26:25.251Z **result_validity_changed** result validity: result-5 -> questioned
- 2026-06-15T19:26:25.251Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:26:36.937Z **cognitive_state_updated** cognitive state updated: problem_ledger.next_best_action next_best_action
- 2026-06-15T19:26:36.937Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:26:42.173Z **node_status_changed** node status: node-2 blocked -> running
- 2026-06-15T19:26:42.174Z **lease_created** lease created: lease-3 on node-2
- 2026-06-15T19:26:42.174Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:26:53.727Z **node_result_recorded** node result recorded: node-2 / result-6
- 2026-06-15T19:26:53.727Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T19:26:53.727Z **node_status_changed** node status: node-2 running -> blocked
- 2026-06-15T19:26:53.728Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:26:55.935Z **result_validity_changed** result validity: result-6 -> questioned
- 2026-06-15T19:26:55.935Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:08.031Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-3
- 2026-06-15T19:27:08.031Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:08.033Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-4
- 2026-06-15T19:27:08.033Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:29.113Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact fact-app-logs
- 2026-06-15T19:27:29.114Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:34.402Z **cognitive_state_updated** cognitive state updated: problem_ledger.next_best_action next_best_action
- 2026-06-15T19:27:34.402Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:40.687Z **cognitive_state_updated** cognitive state updated: subagent_plan.recorded subagent-plan-1
- 2026-06-15T19:27:40.688Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:42.686Z **cognitive_state_updated** cognitive state updated: subagent_plan.recorded subagent-plan-2
- 2026-06-15T19:27:42.687Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:45.175Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T19:27:45.176Z **lease_created** lease created: lease-4 on node-3
- 2026-06-15T19:27:45.176Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:45.299Z **lease_attached** agent attached: /root/inspect_app_logs -> node-3
- 2026-06-15T19:27:45.299Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:45.302Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T19:27:45.302Z **lease_created** lease created: lease-5 on node-4
- 2026-06-15T19:27:45.303Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:45.468Z **lease_attached** agent attached: /root/inspect_db_logs -> node-4
- 2026-06-15T19:27:45.469Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:50.244Z **node_result_recorded** node result recorded: node-3 / result-7 action=read
- 2026-06-15T19:27:50.245Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:50.460Z **node_result_recorded** node result recorded: node-4 / result-8 action=read
- 2026-06-15T19:27:50.461Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:55.921Z **node_result_recorded** node result recorded: node-3 / result-9 action=search
- 2026-06-15T19:27:55.922Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:55.996Z **node_result_recorded** node result recorded: node-4 / result-10 action=search
- 2026-06-15T19:27:55.997Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:56.001Z **node_result_recorded** node result recorded: node-4 / result-11 action=search
- 2026-06-15T19:27:56.002Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:27:56.010Z **node_result_recorded** node result recorded: node-4 / result-12 action=search
- 2026-06-15T19:27:56.011Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:00.645Z **node_result_recorded** node result recorded: node-4 / result-13
- 2026-06-15T19:28:00.645Z **lease_released** lease released: lease-5, reason=result_recorded
- 2026-06-15T19:28:00.646Z **node_status_changed** node status: node-4 running -> completed
- 2026-06-15T19:28:00.647Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:02.815Z **node_result_recorded** node result recorded: node-3 / result-14 action=search
- 2026-06-15T19:28:02.815Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:06.475Z **node_result_recorded** node result recorded: node-3 / result-15
- 2026-06-15T19:28:06.475Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T19:28:06.476Z **node_status_changed** node status: node-3 running -> completed
- 2026-06-15T19:28:06.476Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:14.019Z **result_validity_changed** result validity: result-4 -> accepted
- 2026-06-15T19:28:14.020Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:16.809Z **node_status_changed** node status: node-2 blocked -> running
- 2026-06-15T19:28:16.809Z **lease_created** lease created: lease-6 on node-2
- 2026-06-15T19:28:16.809Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:20.684Z **result_validity_changed** result validity: result-13 -> accepted
- 2026-06-15T19:28:20.684Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:25.152Z **result_validity_changed** result validity: result-15 -> accepted
- 2026-06-15T19:28:25.153Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:26.813Z **node_result_recorded** node result recorded: node-2 / result-16 action=edit
- 2026-06-15T19:28:26.814Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-16 tags=tool_success
- 2026-06-15T19:28:26.814Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:31.564Z **node_result_recorded** node result recorded: node-2 / result-17 action=read
- 2026-06-15T19:28:31.564Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-17 tags=tool_success
- 2026-06-15T19:28:31.565Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:28:35.200Z **node_result_recorded** node result recorded: node-2 / result-18
- 2026-06-15T19:28:35.200Z **lease_released** lease released: lease-6, reason=result_recorded
- 2026-06-15T19:28:35.201Z **node_status_changed** node status: node-2 running -> completed
- 2026-06-15T19:28:35.201Z **node_status_changed** node status: node-5 pending -> ready
- 2026-06-15T19:28:35.201Z **node_status_changed** node status: node-5 ready -> running
- 2026-06-15T19:28:35.202Z **lease_created** lease created: lease-7 on node-5
- 2026-06-15T19:28:35.202Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:28:39.979Z **result_validity_changed** result validity: result-18 -> accepted
- 2026-06-15T19:28:39.979Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:28:43.157Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T19:28:43.158Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-4
- 2026-06-15T19:28:43.158Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-13
- 2026-06-15T19:28:43.158Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-15
- 2026-06-15T19:28:43.159Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-18
- 2026-06-15T19:28:43.159Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:28:46.631Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:28:46.631Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:28:46.631Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:28:46.632Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:28:50.509Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:28:50.510Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:28:50.510Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:28:50.511Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:28:54.719Z **cognitive_state_updated** cognitive state updated: result_adoption result-18
- 2026-06-15T19:28:54.720Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:28:56.439Z **cognitive_state_updated** cognitive state updated: result_adoption result-4
- 2026-06-15T19:28:56.439Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:29:04.507Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-satisfied
- 2026-06-15T19:29:04.507Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-counts
- 2026-06-15T19:29:04.508Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-valid
- 2026-06-15T19:29:04.508Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:29:11.346Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:29:11.346Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:29:11.347Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:29:11.347Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:29:16.258Z **cognitive_state_updated** cognitive state updated: result_adoption result-18
- 2026-06-15T19:29:16.259Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:29:20.725Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:29:20.725Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:29:20.725Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:29:20.726Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:29:27.253Z **node_result_recorded** node result recorded: node-5 / result-19
- 2026-06-15T19:29:27.254Z **lease_released** lease released: lease-7, reason=result_recorded
- 2026-06-15T19:29:27.254Z **node_status_changed** node status: node-5 running -> blocked
- 2026-06-15T19:29:27.254Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:26:14.276Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:26:14.276Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:26:14.278Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:26:14.279Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:26:29.996Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:26:29.997Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:26:29.998Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:26:30.000Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:26:33.690Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:26:33.693Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:26:38.831Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:26:38.833Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:27:04.443Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:27:04.444Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:27:09.872Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:27:09.874Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:27:23.742Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:27:23.744Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:27:31.064Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:27:31.066Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:27:36.216Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:27:36.218Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:27:45.174Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:27:45.174Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:27:45.301Z **tool:spawn_agent** tool call: spawn_agent (completed)
- 2026-06-15T19:27:45.470Z **tool:spawn_agent** tool call: spawn_agent (completed)
- 2026-06-15T19:27:46.718Z **tool:wait_agent** tool call: wait_agent (in_progress)
- 2026-06-15T19:28:00.646Z **tool:wait_agent** tool call: wait_agent (completed)
- 2026-06-15T19:28:02.134Z **tool:wait_agent** tool call: wait_agent (in_progress)
- 2026-06-15T19:28:06.478Z **tool:wait_agent** tool call: wait_agent (completed)
- 2026-06-15T19:28:09.922Z **tool:close_agent** tool call: close_agent (in_progress)
- 2026-06-15T19:28:09.922Z **tool:close_agent** tool call: close_agent (in_progress)
- 2026-06-15T19:28:09.927Z **tool:close_agent** tool call: close_agent (completed)
- 2026-06-15T19:28:09.943Z **tool:close_agent** tool call: close_agent (completed)
-  **tool:wait** tool call: wait (in_progress)
-  **tool:wait** tool call: wait (in_progress)

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
