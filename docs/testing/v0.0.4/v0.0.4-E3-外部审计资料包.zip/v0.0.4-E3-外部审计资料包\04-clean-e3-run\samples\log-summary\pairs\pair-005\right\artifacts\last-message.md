## Summary

**Investigation:** Scanned all 3 `.log` files in `logs/`:

| File | ERROR | WARNING | INFO |
|------|-------|---------|------|
| `app1.log` | 2 | 1 | 2 |
| `app2.log` | 1 | 1 | 3 |
| `db.log` | 1 | 1 | 3 |
| **Total** | **4** | **3** | **8** |

**Output:** Created `summary.csv` with the following content:

```
severity,count
ERROR,4
WARNING,3
INFO,8
```

**Validation:** Confirmed the CSV is correctly formatted (4 lines, valid header, matching counts) using `Import-Csv`.

The task is complete — `W:\app\summary.csv` contains the aggregated log severity counts.