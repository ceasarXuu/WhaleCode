﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-003\right\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-003\right\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-003\right\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 4
- edges: 3
- agents: 0
- collab tool calls: 0
- map runtime events: 127
- output contracts: 1
- fact sources: 1
- accepted results: 5
- questioned/invalid results: 0
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: False
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: final_artifact_hash_missing
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=1 |  |
| required_fact_source_missing | True | at least one fact source | factSources=1 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=11, resultWithClaimEvidence=5 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=11, validityTransitions=5 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | False | each final artifact path resolves to a SHA-256 hash | missingHash=1 | task:task-1\|artifact:W:/app/report.txt |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 1 |
| factSourceCount | 1 |
| activeFactCount | 2 |
| resultCount | 11 |
| acceptedResultCount | 5 |
| questionedOrInvalidResultCount | 0 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 5 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 5 |
| cognitiveStateUpdateCount | 45 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 1 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Analyze access log and create summary report | Parse /app/access_log, compute statistics, and write /app/report.txt with total requests, unique IPs, top 3 URLs, and 404 error count. | 1 | 1 | 2 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-2 | implement_solution | Generate report.txt | completed | 0 | 3 | 1 | 0 | 0 | 0 |
| node-1 | inspect_code_context | Inspect access log format | completed | 0 | 3 | 1 | 0 | 1 | 0 |
| node-4 | final_synthesis | Final summary | blocked | 0 | 1 | 1 | 0 | 0 | 0 |
| node-3 | smoke_test | Validate report format and content | blocked | 0 | 4 | 2 | 0 | 1 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:W:/app/report.txt | task-1 | W:/app/report.txt |  | result-6, result-11, result-8, result-10 | oc-1 | f-impl, f-done, f-test, f-test-pass | artifactRef=W:/app/report.txt, validatorRef=Shell validation script reports ALL CHECKS PASSED | Shell command: Get-Content + format validation of report.txt, Shell validation script reports ALL CHECKS PASSED, Shell: Get-Content + 7-line verification of report.txt |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-4 | node-2 | unreviewed |  |  |  |  |
| result-5 | node-2 | unreviewed |  |  |  |  |
| result-6 | node-2 | accepted | f-impl | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/report.txt","validatorRef":null} |  | Successfully ran PowerShell script that parsed access_log and wrote report.txt. |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | accepted | f-1 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/access_log","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":"fs-1","traceEventId":null,"artifactRef":null,"validatorRef":null} |  | Inspected log file directly - confirmed 2000 lines in Apache CLF format with IP, date, request, status, size fields. |
| result-11 | node-4 | accepted | f-done | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/report.txt","validatorRef":null} |  | All work is complete and validated. The final_synthesis node was blocked due to a TaskSpace runtime criteria-tracking issue, not a work quality issue. |
| result-7 | node-3 | unreviewed |  |  |  |  |
| result-8 | node-3 | accepted | f-test | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/report.txt","validatorRef":null} | Shell command: Get-Content + format validation of report.txt | Test shell command validated all 7 lines of report.txt match expectations |
| result-9 | node-3 | unreviewed |  |  |  |  |
| result-10 | node-3 | accepted | f-test-pass | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/report.txt","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":null,"validatorRef":"Shell validation script reports ALL CHECKS PASSED"} | Shell: Get-Content + 7-line verification of report.txt | Validation succeeded via shell commands in node-3. All 7 report lines match expected values. |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-2 | node-3 |
| node-2 | node-4 |

## Timeline

- 2026-06-15T18:25:05.734Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T18:25:07.852Z **task_created** task created: task-1 Analyze access log and create summary report
- 2026-06-15T18:25:07.853Z **map_created** map created: map-1 Analyze access log and create summary report
- 2026-06-15T18:25:07.854Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T18:25:07.854Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T18:25:07.855Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T18:25:07.855Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:25:11.701Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:25:11.702Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:25:11.702Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:25:11.702Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:25:11.703Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:25:11.703Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:25:13.688Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T18:25:13.688Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:25:15.295Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T18:25:15.296Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:25:21.329Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T18:25:21.329Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T18:25:21.330Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:25:27.854Z **node_result_recorded** node result recorded: node-1 / result-2 action=read
- 2026-06-15T18:25:27.855Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T18:25:27.855Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:25:34.355Z **tool_action_blocked** tool action blocked: node-1 edit via shell_command
- 2026-06-15T18:25:34.355Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:25:36.752Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact f-1
- 2026-06-15T18:25:36.752Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:25:38.939Z **node_result_recorded** node result recorded: node-1 / result-3
- 2026-06-15T18:25:38.939Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T18:25:38.940Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T18:25:38.940Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T18:25:38.940Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T18:25:38.941Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T18:25:38.941Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:25:44.399Z **result_validity_changed** result validity: result-3 -> accepted
- 2026-06-15T18:25:44.400Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:25:51.037Z **node_result_recorded** node result recorded: node-2 / result-4 action=edit
- 2026-06-15T18:25:51.037Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-4 tags=tool_success
- 2026-06-15T18:25:51.038Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:25:55.765Z **node_result_recorded** node result recorded: node-2 / result-5 action=read
- 2026-06-15T18:25:55.765Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-5 tags=tool_success
- 2026-06-15T18:25:55.766Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:26:00.879Z **node_result_recorded** node result recorded: node-2 / result-6
- 2026-06-15T18:26:00.880Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T18:26:00.880Z **node_status_changed** node status: node-2 running -> completed
- 2026-06-15T18:26:00.880Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T18:26:00.881Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T18:26:00.881Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T18:26:00.881Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:07.261Z **result_validity_changed** result validity: result-6 -> accepted
- 2026-06-15T18:26:07.261Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:13.133Z **node_result_recorded** node result recorded: node-3 / result-7 action=read
- 2026-06-15T18:26:13.134Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-7 tags=tool_success
- 2026-06-15T18:26:13.134Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:15.896Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:26:15.897Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:26:15.897Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:26:15.897Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:26:15.898Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:26:15.898Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:19.514Z **tool_action_blocked** tool action blocked: node-3 unknown via shell_command
- 2026-06-15T18:26:19.514Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:30.223Z **node_result_recorded** node result recorded: node-3 / result-8 action=read
- 2026-06-15T18:26:30.224Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-8 tags=tool_success
- 2026-06-15T18:26:30.224Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:35.715Z **result_validity_changed** result validity: result-8 -> accepted
- 2026-06-15T18:26:35.716Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:45.575Z **node_result_recorded** node result recorded: node-3 / result-9 action=read
- 2026-06-15T18:26:45.576Z **taskspace_trace_event_recorded** trace event: trace-7 result=result-9 tags=tool_success
- 2026-06-15T18:26:45.576Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:53.399Z **node_result_recorded** node result recorded: node-3 / result-10
- 2026-06-15T18:26:53.399Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T18:26:53.400Z **node_status_changed** node status: node-3 running -> blocked
- 2026-06-15T18:26:53.400Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:56.396Z **result_validity_changed** result validity: result-10 -> accepted
- 2026-06-15T18:26:56.397Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:26:59.200Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:26:59.201Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:26:59.201Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:26:59.202Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:26:59.202Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:26:59.202Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:27:00.668Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T18:27:00.669Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T18:27:00.670Z **lease_created** lease created: lease-4 on node-4
- 2026-06-15T18:27:00.670Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:03.324Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T18:27:03.325Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-3
- 2026-06-15T18:27:03.325Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-6
- 2026-06-15T18:27:03.325Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:05.224Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact f-report-final
- 2026-06-15T18:27:05.225Z **cognitive_state_updated** cognitive state updated: result_adoption.fact result-10
- 2026-06-15T18:27:05.225Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:10.170Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:27:10.170Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:27:10.171Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:27:10.171Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:27:10.171Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:27:10.171Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:14.532Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-complete
- 2026-06-15T18:27:14.533Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:19.158Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:27:19.158Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:27:19.159Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:27:19.159Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:27:19.159Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:27:19.160Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:24.648Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s1
- 2026-06-15T18:27:24.648Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s2
- 2026-06-15T18:27:24.649Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s3
- 2026-06-15T18:27:24.649Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s4
- 2026-06-15T18:27:24.649Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s5
- 2026-06-15T18:27:24.650Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s6
- 2026-06-15T18:27:24.650Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:29.868Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-final
- 2026-06-15T18:27:29.868Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-3
- 2026-06-15T18:27:29.868Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-6
- 2026-06-15T18:27:29.869Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-10
- 2026-06-15T18:27:29.869Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:32.466Z **cognitive_state_updated** cognitive state updated: result_adoption result-10
- 2026-06-15T18:27:32.466Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:37.178Z **node_result_recorded** node result recorded: node-4 / result-11
- 2026-06-15T18:27:37.178Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T18:27:37.178Z **node_status_changed** node status: node-4 running -> blocked
- 2026-06-15T18:27:37.179Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:27:41.979Z **result_validity_changed** result validity: result-11 -> accepted
- 2026-06-15T18:27:41.979Z **snapshot_updated** snapshot updated: maps=1 nodes=4

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
