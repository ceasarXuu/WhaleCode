﻿# TaskSpace Runtime Bottleneck Report

- timing_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\suite-timing.json
- score_valid: True
- speedup_evidence_valid: False
- speedup_decision: speedup_blocked_instrumentation
- speedup_decision_reason: runtime_optimization_status_blocked
- timing_quality: incomplete
- runtime_optimization_status: blocked
- bottleneck_classification: validator_bound
- wait_attribution_status: missing
- resource_wait_attribution_mode: serial_with_cache_lock_observed
- runtime_optimization_blockers: child_sample:child_pair:missing_wait_attribution:model_request_duration_ms, child_sample:child_pair:unavailable_wait_attribution:model_queue_wait_ms, child_sample:child_pair:unavailable_wait_attribution:model_retry_backoff_ms, child_sample:missing_wait_attribution:model_request_duration_ms, child_sample:unavailable_wait_attribution:model_queue_wait_ms, child_sample:unavailable_wait_attribution:model_retry_backoff_ms, missing_wait_attribution:model_request_duration_ms, unavailable_wait_attribution:model_queue_wait_ms, unavailable_wait_attribution:model_retry_backoff_ms
- wait_attribution_missing_fields: model_request_duration_ms
- wait_attribution_unavailable_fields: model_queue_wait_ms=whale_jsonl_provider_queue_retry_telemetry_unavailable, model_retry_backoff_ms=whale_jsonl_provider_queue_retry_telemetry_unavailable

## Phase Durations
- agent_duration_ms: 4744306ms
- model_request_duration_ms: null
- public_validation_duration_ms: 3061684ms
- hidden_oracle_duration_ms: 10974ms
- docker_build_duration_ms: 84341ms
- docker_run_duration_ms: 2727821ms
- docker_cleanup_duration_ms: 41361ms
- process_launch_wait_ms: 558ms
- resource_wait_ms_total: 0ms

## Top Spans
- agent: 4744306ms
- public_validation: 3061684ms
- docker_run: 2727821ms

## Docker Cache
- repeated_docker_cache_keys: 39f1ba0f1577709348c31bfaa12269e0, 6633add605686b982cb1857a2dbd2009, b408a94979f7bd3a740312cb25c7221b
