﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-002\left\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-002\left\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-002\left\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 3
- edges: 2
- agents: 0
- collab tool calls: 0
- map runtime events: 87
- output contracts: 2
- fact sources: 2
- accepted results: 2
- questioned/invalid results: 0
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: False
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: final_artifact_hash_missing
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=2 |  |
| required_fact_source_missing | True | at least one fact source | factSources=2 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=10, resultWithClaimEvidence=2 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=10, validityTransitions=2 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | False | each final artifact path resolves to a SHA-256 hash | missingHash=1 | task:task-1\|artifact:W:\app\report.txt |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 2 |
| factSourceCount | 2 |
| activeFactCount | 1 |
| resultCount | 10 |
| acceptedResultCount | 2 |
| questionedOrInvalidResultCount | 0 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 2 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 2 |
| cognitiveStateUpdateCount | 21 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 1 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Analyze web server access log and generate summary report | Read /app/access_log, compute statistics, and write /app/report.txt with the specified format. | 2 | 2 | 1 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-1 | inspect_code_context | Inspect log file and understand format | completed | 0 | 3 | 1 | 0 | 1 | 0 |
| node-2 | implement_solution | Generate summary report from access log | completed | 0 | 6 | 1 | 0 | 0 | 0 |
| node-3 | final_synthesis | Final report summary | blocked | 0 | 1 | 0 | 0 | 0 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:W:\app\report.txt | task-1 | W:\app\report.txt |  | result-9 | oc-1, oc-2 | c-2 | artifactRef=W:\app\report.txt, artifactRef=W:\app\access_log |  |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | accepted | c-1 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\access_log","validatorRef":null} |  | Inspected log file, confirmed Apache combined log format. Evidence: file listing and sample lines from the actual log. |
| result-4 | node-2 | unreviewed |  |  |  |  |
| result-5 | node-2 | unreviewed |  |  |  |  |
| result-6 | node-2 | unreviewed |  |  |  |  |
| result-7 | node-2 | unreviewed |  |  |  |  |
| result-8 | node-2 | unreviewed |  |  |  |  |
| result-9 | node-2 | accepted | c-2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\report.txt","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\access_log","validatorRef":null} |  | Report was generated successfully and all numbers were independently verified against the log file. The report file matches the exact format specified. |
| result-10 | node-3 | unreviewed |  |  |  |  |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-2 | node-3 |

## Timeline

- 2026-06-15T18:18:40.656Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T18:18:44.517Z **task_created** task created: task-1 Analyze web server access log and generate summary report
- 2026-06-15T18:18:44.518Z **map_created** map created: map-1 Analyze web server access log and generate summary report
- 2026-06-15T18:18:44.519Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:18:44.519Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:18:44.519Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T18:18:44.520Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T18:18:44.520Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T18:18:44.521Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:18:49.975Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T18:18:49.975Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:18:49.976Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-2
- 2026-06-15T18:18:49.977Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:18:49.978Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T18:18:49.978Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:18:57.661Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T18:18:57.662Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T18:18:57.662Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:19:02.450Z **node_result_recorded** node result recorded: node-1 / result-2 action=read
- 2026-06-15T18:19:02.451Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T18:19:02.452Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:19:09.619Z **tool_action_blocked** tool action blocked: node-1 edit via shell_command
- 2026-06-15T18:19:09.620Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:19:12.427Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-2
- 2026-06-15T18:19:12.427Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:19:15.231Z **node_result_recorded** node result recorded: node-1 / result-3
- 2026-06-15T18:19:15.231Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T18:19:15.231Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T18:19:15.232Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T18:19:15.232Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T18:19:15.233Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T18:19:15.233Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:19:21.549Z **result_validity_changed** result validity: result-3 -> accepted
- 2026-06-15T18:19:21.550Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:19:28.400Z **node_result_recorded** node result recorded: node-2 / result-4 action=edit
- 2026-06-15T18:19:28.400Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-4 tags=tool_success
- 2026-06-15T18:19:28.401Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:19:33.435Z **node_result_recorded** node result recorded: node-2 / result-5 action=read
- 2026-06-15T18:19:33.436Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-5 tags=tool_success
- 2026-06-15T18:19:33.437Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:19:41.172Z **node_result_recorded** node result recorded: node-2 / result-6 action=read
- 2026-06-15T18:19:41.173Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-6 tags=tool_success
- 2026-06-15T18:19:41.173Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:19:48.514Z **node_result_recorded** node result recorded: node-2 / result-7 action=read
- 2026-06-15T18:19:48.515Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-7 tags=tool_success
- 2026-06-15T18:19:48.516Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:19:54.906Z **node_result_recorded** node result recorded: node-2 / result-8 action=read
- 2026-06-15T18:19:54.906Z **taskspace_trace_event_recorded** trace event: trace-7 result=result-8 tags=tool_success
- 2026-06-15T18:19:54.907Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:19:58.611Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:19:58.611Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:19:58.612Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:20:00.921Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact f-1
- 2026-06-15T18:20:00.922Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:20:03.114Z **node_result_recorded** node result recorded: node-2 / result-9
- 2026-06-15T18:20:03.114Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T18:20:03.115Z **node_status_changed** node status: node-2 running -> completed
- 2026-06-15T18:20:03.115Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:20:05.820Z **result_validity_changed** result validity: result-9 -> accepted
- 2026-06-15T18:20:05.821Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:20:07.857Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T18:20:07.858Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T18:20:07.858Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T18:20:07.858Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:20:11.473Z **cognitive_state_updated** cognitive state updated: result_adoption result-9
- 2026-06-15T18:20:11.477Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:20:15.407Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:20:15.407Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:20:15.407Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:20:21.312Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T18:20:21.313Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-9
- 2026-06-15T18:20:21.313Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:20:25.171Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:20:25.171Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:20:25.171Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:20:31.495Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:20:31.495Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:20:37.215Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:20:37.215Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:20:37.216Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:20:37.216Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:20:42.985Z **node_result_recorded** node result recorded: node-3 / result-10
- 2026-06-15T18:20:42.985Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T18:20:42.986Z **node_status_changed** node status: node-3 running -> blocked
- 2026-06-15T18:20:42.986Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:20:45.457Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-done
- 2026-06-15T18:20:45.457Z **snapshot_updated** snapshot updated: maps=1 nodes=3

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
