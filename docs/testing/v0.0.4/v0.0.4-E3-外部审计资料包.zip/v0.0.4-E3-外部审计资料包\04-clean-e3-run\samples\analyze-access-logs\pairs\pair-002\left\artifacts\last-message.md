The report has been successfully generated. Here's a summary of the work:

**Investigation phase:** Inspected `/app/access_log` (Apache combined log format, 1665 KB, 2000 lines).

**Implementation:** Parsed the log with PowerShell to compute all four statistics and wrote the results to `/app/report.txt`.

**Verification:** Independently re-validated all numbers using a different parsing approach to confirm correctness.

**Final report** (`W:\app\report.txt`):
```
Total requests: 2000
Unique IP addresses: 273
Top 3 URLs:
  /order-confirmation: 54
  /product/456: 53
  /about.html: 52
404 errors: 83
```

All values were cross-checked against the raw log data — every line was parsed, all HTTP methods (GET, POST, PUT, DELETE, HEAD, OPTIONS) were included in URL counting, and the 404 count was verified against known HTTP status code distribution.