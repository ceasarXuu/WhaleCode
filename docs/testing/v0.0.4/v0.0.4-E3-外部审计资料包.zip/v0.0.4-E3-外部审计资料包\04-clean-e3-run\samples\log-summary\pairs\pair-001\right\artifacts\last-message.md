The task is fully complete. Here's your final output:

---

**`W:\app\summary.csv`** has been created with the following validated content:

```
severity,count
ERROR,4
WARNING,3
INFO,8
```

**Breakdown by file:**

| File | ERROR | WARNING | INFO |
|------|-------|---------|------|
| `logs/app1.log` | 2 | 1 | 2 |
| `logs/app2.log` | 1 | 1 | 3 |
| `logs/db.log` | 1 | 1 | 3 |
| **Total** | **4** | **3** | **8** |

The CSV is a valid 4-line file with the required header and one data row per severity level. All counts were verified against the raw log file contents.