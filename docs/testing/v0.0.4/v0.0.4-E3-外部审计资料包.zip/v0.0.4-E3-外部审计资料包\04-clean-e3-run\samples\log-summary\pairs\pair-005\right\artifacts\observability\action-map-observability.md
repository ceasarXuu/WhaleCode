﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-005\right\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-005\right\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-005\right\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 9
- edges: 10
- agents: 3
- collab tool calls: 11
- map runtime events: 174
- output contracts: 2
- fact sources: 2
- accepted results: 6
- questioned/invalid results: 3
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: True
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: none
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=2 |  |
| required_fact_source_missing | True | at least one fact source | factSources=2 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=24, resultWithClaimEvidence=6 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=24, validityTransitions=10 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | True | each final artifact path resolves to a SHA-256 hash | missingHash=0 |  |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 2 |
| factSourceCount | 2 |
| activeFactCount | 0 |
| resultCount | 24 |
| acceptedResultCount | 6 |
| questionedOrInvalidResultCount | 3 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 6 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 10 |
| cognitiveStateUpdateCount | 19 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 0 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Scan log files and generate summary CSV | Scan all .log files in logs/, count ERROR/WARNING/INFO lines, and output summary.csv | 2 | 2 | 0 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-5 | inspect_code_context | Inspect db.log | completed | 1 | 4 | 2 | 0 | 0 | 0 |
| node-2 | implement_solution | Write summary.csv | blocked | 0 | 1 | 0 | 1 | 0 | 0 |
| node-4 | inspect_code_context | Inspect app2.log | completed | 1 | 4 | 1 | 0 | 0 | 0 |
| node-6 | implement_solution | Write summary.csv | blocked | 0 | 1 | 0 | 1 | 0 | 0 |
| node-9 | final_synthesis | Summarize results | blocked | 0 | 1 | 0 | 0 | 0 | 0 |
| node-3 | inspect_code_context | Inspect app1.log | completed | 1 | 4 | 1 | 0 | 0 | 0 |
| node-1 | inspect_code_context | Scan log files and count severities | completed | 0 | 4 | 1 | 0 | 1 | 0 |
| node-8 | smoke_test | Validate summary.csv | blocked | 0 | 2 | 0 | 1 | 0 | 0 |
| node-7 | implement_solution | Write summary.csv | completed | 0 | 3 | 1 | 0 | 0 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:summary.csv | task-1 | summary.csv | 6c0c7125821b07e2 | result-21 | oc-1, oc-sub-1 | c-csv-1, c-csv-2, c-csv-3, c-csv-4 | artifactRef=summary.csv |  |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-9 | node-5 | unreviewed |  |  |  |  |
| result-12 | node-5 | unreviewed |  |  |  |  |
| result-15 | node-5 | accepted | c-sub-1 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"logs/app1.log","validatorRef":null} |  | Subagent confirmed counts match main agent verification. |
| result-17 | node-5 | accepted | c-sub-3 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"logs/db.log","validatorRef":null} |  | Subagent confirmed counts match main agent verification. |
| result-5 | node-2 | questioned |  | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"summary.csv not created yet","validatorRef":null} |  | Blocked by TaskSpace policy, no edit performed. |
| result-8 | node-4 | unreviewed |  |  |  |  |
| result-11 | node-4 | unreviewed |  |  |  |  |
| result-13 | node-4 | unreviewed |  |  |  |  |
| result-16 | node-4 | accepted | c-sub-2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"logs/app2.log","validatorRef":null} |  | Subagent confirmed counts match main agent verification. |
| result-6 | node-6 | questioned |  | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"summary.csv was not written","validatorRef":null} |  | Blocked by task-level broad inspect policy. |
| result-24 | node-9 | unreviewed |  |  |  |  |
| result-7 | node-3 | unreviewed |  |  |  |  |
| result-10 | node-3 | unreviewed |  |  |  |  |
| result-14 | node-3 | unreviewed |  |  |  |  |
| result-18 | node-3 | accepted | c-sub-1b | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"logs/app1.log","validatorRef":null} |  | Subagent confirmed counts. |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | unreviewed |  |  |  |  |
| result-4 | node-1 | accepted | c-1, c-2, c-3, c-4 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"logs/app1.log","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"logs/app2.log","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"logs/db.log","validatorRef":null} |  | Subagent results confirmed: app1.log ERROR=2 WARNING=1 INFO=2, app2.log ERROR=1 WARNING=1 INFO=3, db.log ERROR=1 WARNING=1 INFO=3. Totals: ERROR=4, WARNING=3, INFO=8. |
| result-22 | node-8 | unreviewed |  |  |  |  |
| result-23 | node-8 | questioned |  | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"summary.csv","validatorRef":"Import-Csv validation"} |  | Validation passed in shell but system could not recognize as recorded test action. |
| result-19 | node-7 | unreviewed |  |  |  |  |
| result-20 | node-7 | unreviewed |  |  |  |  |
| result-21 | node-7 | accepted | c-csv-1, c-csv-2, c-csv-3, c-csv-4 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"summary.csv","validatorRef":null} |  | summary.csv successfully written with correct data. |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-1 | node-3 |
| node-1 | node-4 |
| node-1 | node-5 |
| node-1 | node-6 |
| node-3 | node-7 |
| node-4 | node-7 |
| node-5 | node-7 |
| node-7 | node-8 |
| node-7 | node-9 |

## Timeline

- 2026-06-15T19:34:42.661Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T19:34:45.892Z **task_created** task created: task-1 Scan log files and generate summary CSV
- 2026-06-15T19:34:45.892Z **map_created** map created: map-1 Scan log files and generate summary CSV
- 2026-06-15T19:34:45.892Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T19:34:45.893Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T19:34:45.893Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T19:34:45.893Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:34:52.070Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T19:34:52.071Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:34:52.072Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T19:34:52.072Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:34:54.558Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:34:54.558Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:34:54.558Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:34:54.559Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:35:01.327Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T19:35:01.327Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T19:35:01.328Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:35:07.832Z **node_result_recorded** node result recorded: node-1 / result-2 action=search
- 2026-06-15T19:35:07.833Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T19:35:07.834Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:35:13.374Z **node_result_recorded** node result recorded: node-1 / result-3 action=read
- 2026-06-15T19:35:13.375Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-3 tags=tool_success
- 2026-06-15T19:35:13.375Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:35:16.705Z **tool_action_blocked** tool action blocked: node-1 edit via shell_command
- 2026-06-15T19:35:16.706Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:35:19.167Z **node_result_recorded** node result recorded: node-1 / result-4
- 2026-06-15T19:35:19.168Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T19:35:19.168Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T19:35:19.169Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T19:35:19.169Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T19:35:19.169Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T19:35:19.170Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:35:26.195Z **result_validity_changed** result validity: result-4 -> accepted
- 2026-06-15T19:35:26.195Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:35:37.387Z **node_result_recorded** node result recorded: node-2 / result-5
- 2026-06-15T19:35:37.387Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T19:35:37.387Z **node_status_changed** node status: node-2 running -> blocked
- 2026-06-15T19:35:37.388Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:35:41.641Z **result_validity_changed** result validity: result-5 -> questioned
- 2026-06-15T19:35:41.641Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:35:48.926Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T19:35:48.926Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:35:48.929Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T19:35:48.929Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T19:35:48.931Z **node_status_changed** node status: node-5 pending -> ready
- 2026-06-15T19:35:48.931Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T19:35:58.150Z **node_status_changed** node status: node-6 pending -> ready
- 2026-06-15T19:35:58.150Z **node_status_changed** node status: node-6 ready -> running
- 2026-06-15T19:35:58.150Z **lease_created** lease created: lease-3 on node-6
- 2026-06-15T19:35:58.151Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:07.731Z **node_result_recorded** node result recorded: node-6 / result-6
- 2026-06-15T19:36:07.731Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T19:36:07.732Z **node_status_changed** node status: node-6 running -> blocked
- 2026-06-15T19:36:07.732Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:09.719Z **result_validity_changed** result validity: result-6 -> questioned
- 2026-06-15T19:36:09.719Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:16.922Z **cognitive_state_updated** cognitive state updated: result_adoption result-4
- 2026-06-15T19:36:16.922Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:30.966Z **task_routed** task routed: task-1 -> task-1
- 2026-06-15T19:36:30.966Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:34.582Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-sub-1
- 2026-06-15T19:36:34.582Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:47.832Z **cognitive_state_updated** cognitive state updated: subagent_plan.recorded subagent-plan-1
- 2026-06-15T19:36:47.833Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:51.165Z **cognitive_state_updated** cognitive state updated: subagent_plan.recorded subagent-plan-2
- 2026-06-15T19:36:51.165Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:51.167Z **cognitive_state_updated** cognitive state updated: subagent_plan.recorded subagent-plan-3
- 2026-06-15T19:36:51.167Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:54.665Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T19:36:54.665Z **lease_created** lease created: lease-4 on node-3
- 2026-06-15T19:36:54.666Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:54.784Z **lease_attached** agent attached: /root/inspect_app1_log -> node-3
- 2026-06-15T19:36:54.784Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:54.787Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T19:36:54.787Z **lease_created** lease created: lease-5 on node-4
- 2026-06-15T19:36:54.788Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:54.959Z **lease_attached** agent attached: /root/inspect_app2_log -> node-4
- 2026-06-15T19:36:54.959Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:54.962Z **node_status_changed** node status: node-5 ready -> running
- 2026-06-15T19:36:54.962Z **lease_created** lease created: lease-6 on node-5
- 2026-06-15T19:36:54.963Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:36:55.135Z **lease_attached** agent attached: /root/inspect_db_log -> node-5
- 2026-06-15T19:36:55.136Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:00.175Z **node_result_recorded** node result recorded: node-3 / result-7 action=read
- 2026-06-15T19:37:00.175Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:00.354Z **node_result_recorded** node result recorded: node-4 / result-8 action=read
- 2026-06-15T19:37:00.355Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:00.419Z **node_result_recorded** node result recorded: node-5 / result-9 action=read
- 2026-06-15T19:37:00.419Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:04.836Z **node_result_recorded** node result recorded: node-3 / result-10 action=read
- 2026-06-15T19:37:04.836Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:04.966Z **node_result_recorded** node result recorded: node-4 / result-11 action=read
- 2026-06-15T19:37:04.967Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:05.259Z **node_result_recorded** node result recorded: node-5 / result-12 action=read
- 2026-06-15T19:37:05.260Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:11.303Z **node_result_recorded** node result recorded: node-4 / result-13 action=search
- 2026-06-15T19:37:11.304Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:11.527Z **node_result_recorded** node result recorded: node-3 / result-14 action=search
- 2026-06-15T19:37:11.528Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:11.581Z **node_result_recorded** node result recorded: node-5 / result-15 action=search
- 2026-06-15T19:37:11.582Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:14.167Z **node_result_recorded** node result recorded: node-4 / result-16
- 2026-06-15T19:37:14.168Z **lease_released** lease released: lease-5, reason=result_recorded
- 2026-06-15T19:37:14.168Z **node_status_changed** node status: node-4 running -> completed
- 2026-06-15T19:37:14.169Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:14.930Z **node_result_recorded** node result recorded: node-5 / result-17
- 2026-06-15T19:37:14.930Z **lease_released** lease released: lease-6, reason=result_recorded
- 2026-06-15T19:37:14.931Z **node_status_changed** node status: node-5 running -> completed
- 2026-06-15T19:37:14.931Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:15.110Z **node_result_recorded** node result recorded: node-3 / result-18
- 2026-06-15T19:37:15.110Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T19:37:15.111Z **node_status_changed** node status: node-3 running -> completed
- 2026-06-15T19:37:15.111Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:22.835Z **result_validity_changed** result validity: result-4 -> accepted
- 2026-06-15T19:37:22.835Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T19:37:25.954Z **node_status_changed** node status: node-7 pending -> ready
- 2026-06-15T19:37:25.955Z **node_status_changed** node status: node-7 ready -> running
- 2026-06-15T19:37:25.955Z **lease_created** lease created: lease-7 on node-7
- 2026-06-15T19:37:25.955Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:37:31.061Z **result_validity_changed** result validity: result-16 -> accepted
- 2026-06-15T19:37:31.061Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:37:34.480Z **result_validity_changed** result validity: result-15 -> accepted
- 2026-06-15T19:37:34.480Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:37:34.482Z **result_validity_changed** result validity: result-17 -> accepted
- 2026-06-15T19:37:34.482Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:37:38.598Z **result_validity_changed** result validity: result-18 -> accepted
- 2026-06-15T19:37:38.599Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:37:43.433Z **node_result_recorded** node result recorded: node-7 / result-19 action=edit
- 2026-06-15T19:37:43.434Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-19 tags=tool_success
- 2026-06-15T19:37:43.434Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:37:48.421Z **node_result_recorded** node result recorded: node-7 / result-20 action=read
- 2026-06-15T19:37:48.421Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-20 tags=tool_success
- 2026-06-15T19:37:48.422Z **snapshot_updated** snapshot updated: maps=1 nodes=7
- 2026-06-15T19:37:51.372Z **node_result_recorded** node result recorded: node-7 / result-21
- 2026-06-15T19:37:51.373Z **lease_released** lease released: lease-7, reason=result_recorded
- 2026-06-15T19:37:51.373Z **node_status_changed** node status: node-7 running -> completed
- 2026-06-15T19:37:51.373Z **node_status_changed** node status: node-8 pending -> ready
- 2026-06-15T19:37:51.374Z **node_status_changed** node status: node-8 ready -> running
- 2026-06-15T19:37:51.374Z **lease_created** lease created: lease-8 on node-8
- 2026-06-15T19:37:51.374Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:37:54.245Z **result_validity_changed** result validity: result-21 -> accepted
- 2026-06-15T19:37:54.246Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:37:59.828Z **node_result_recorded** node result recorded: node-8 / result-22 action=read
- 2026-06-15T19:37:59.829Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-22 tags=tool_success
- 2026-06-15T19:37:59.829Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:38:06.679Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:38:06.679Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:38:13.222Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-validation-1
- 2026-06-15T19:38:13.222Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:38:17.777Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-validation-1
- 2026-06-15T19:38:17.777Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-21
- 2026-06-15T19:38:17.778Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:38:21.284Z **node_result_recorded** node result recorded: node-8 / result-23
- 2026-06-15T19:38:21.285Z **lease_released** lease released: lease-8, reason=result_recorded
- 2026-06-15T19:38:21.285Z **node_status_changed** node status: node-8 running -> blocked
- 2026-06-15T19:38:21.286Z **snapshot_updated** snapshot updated: maps=1 nodes=8
- 2026-06-15T19:38:23.376Z **node_status_changed** node status: node-9 pending -> ready
- 2026-06-15T19:38:23.377Z **node_status_changed** node status: node-9 ready -> running
- 2026-06-15T19:38:23.377Z **lease_created** lease created: lease-9 on node-9
- 2026-06-15T19:38:23.378Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:38:25.493Z **result_validity_changed** result validity: result-23 -> questioned
- 2026-06-15T19:38:25.494Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:38:27.476Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:38:27.476Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:38:27.476Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:38:31.968Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:38:31.969Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:38:31.969Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:38:31.969Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:38:36.124Z **node_result_recorded** node result recorded: node-9 / result-24
- 2026-06-15T19:38:36.124Z **lease_released** lease released: lease-9, reason=result_recorded
- 2026-06-15T19:38:36.124Z **node_status_changed** node status: node-9 running -> blocked
- 2026-06-15T19:38:36.125Z **snapshot_updated** snapshot updated: maps=1 nodes=9
- 2026-06-15T19:35:52.434Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:35:52.434Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:35:52.435Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:35:52.436Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:35:52.437Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:35:52.439Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:36:02.869Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:36:02.871Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:36:25.942Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:36:25.944Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:36:36.383Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:36:36.385Z **tool:spawn_agent** tool call: spawn_agent (failed)
- 2026-06-15T19:36:54.663Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:36:54.663Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:36:54.663Z **tool:spawn_agent** tool call: spawn_agent (in_progress)
- 2026-06-15T19:36:54.786Z **tool:spawn_agent** tool call: spawn_agent (completed)
- 2026-06-15T19:36:54.961Z **tool:spawn_agent** tool call: spawn_agent (completed)
- 2026-06-15T19:36:55.137Z **tool:spawn_agent** tool call: spawn_agent (completed)
- 2026-06-15T19:36:56.753Z **tool:wait_agent** tool call: wait_agent (in_progress)
- 2026-06-15T19:37:14.169Z **tool:wait_agent** tool call: wait_agent (completed)
-  **tool:wait** tool call: wait (in_progress)

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
