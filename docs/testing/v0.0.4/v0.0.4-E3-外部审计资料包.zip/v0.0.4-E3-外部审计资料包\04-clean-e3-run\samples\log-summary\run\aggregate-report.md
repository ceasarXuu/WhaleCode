﻿# TaskSpace Benchmark Aggregate Report

- run_validity: valid
- score_ready: False
- score_valid: False
- score_block_reason: audit_required
- score_fields_enabled: False
- diagnostic_comparison_enabled: False
- score_invalid_reason: 
- engineering_unclean_count: 0
- audit_required_count: 5
- agent_exec_timeout_count: 0
- clean_comparable_pair_count: 0
- invalid_run_reason: 
- first_failure_artifact: 
- diagnostic_note: score fields disabled because E3 human review is pending
- configured_pairs: 5
- eligible_pairs: 5
- environment_failed_pairs: 0
- partial_pairs: 5
- e3_candidate_pairs: 5
- audit_ready_pairs: 0
- e3_included_pairs: 0
- all_pairs: 5
- valid_utility_pairs: 0
- valid_e3_pairs: 0
- excluded_pairs: 5
- both_success: 0
- both_failed: 0
- inconclusive: 0

## Failure Taxonomy Summary
- agent_patch_wrong: 4
- audit_unclean: 5
- subagent_noise_or_unused: 5

## Graph Health Summary
- graph_health_files: 10
- high_blocked_node_ratio: 4
- high_unreviewed_result_ratio: 5
- low_decision_density: 2
- subagent_no_decision_yield: 5

## Timing Summary
- timing_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\sample-timing.json
- runtime_bottleneck_path: 
- bottleneck_classification: validator_bound
- speedup_evidence_valid: False
- speedup_decision: 
- speedup_decision_reason: 
- runtime_optimization_status: blocked
- wait_attribution_status: missing
- wait_attribution_missing_fields: model_request_duration_ms
- wait_attribution_unavailable_fields: model_queue_wait_ms=whale_jsonl_provider_queue_retry_telemetry_unavailable, model_retry_backoff_ms=whale_jsonl_provider_queue_retry_telemetry_unavailable
- top_span: agent=1595216ms
- top_span: public_validation=895998ms
- top_span: docker_run=783416ms
- agent_median_ms: 290408
- agent_p95_ms: 411184
- docker_build_median_ms: 5239
- docker_build_p95_ms: 5885
- docker_cleanup_median_ms: 2847
- docker_cleanup_p95_ms: 2980
- docker_run_median_ms: 142922
- docker_run_p95_ms: 194481
- hidden_oracle_median_ms: 972
- hidden_oracle_p95_ms: 1047
- public_validation_median_ms: 166408
- public_validation_p95_ms: 216594
- total_median_ms: 543346
- total_p95_ms: 665293
- repeated_docker_cache_keys: 39f1ba0f1577709348c31bfaa12269e0

## Pair 1
- pair_report: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-001\pair-report.md
- audit_manifest: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-001\audit.json
- reported_evidence_level: E3-candidate
- included_in_utility_aggregate: False
- included_in_e3_aggregate: False
- human_review_completed: False
- human_review_decision: 
- human_review_disagreement: False
- utility_direction: score_disabled
- failure_taxonomy: agent_patch_wrong, subagent_noise_or_unused, audit_unclean
- evidence_gate_failures: none
- e3_gate_failures: e3_human_review_not_completed

## Pair 2
- pair_report: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-002\pair-report.md
- audit_manifest: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-002\audit.json
- reported_evidence_level: E3-candidate
- included_in_utility_aggregate: False
- included_in_e3_aggregate: False
- human_review_completed: False
- human_review_decision: 
- human_review_disagreement: False
- utility_direction: score_disabled
- failure_taxonomy: subagent_noise_or_unused, audit_unclean
- evidence_gate_failures: none
- e3_gate_failures: e3_human_review_not_completed

## Pair 3
- pair_report: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-003\pair-report.md
- audit_manifest: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-003\audit.json
- reported_evidence_level: E3-candidate
- included_in_utility_aggregate: False
- included_in_e3_aggregate: False
- human_review_completed: False
- human_review_decision: 
- human_review_disagreement: False
- utility_direction: score_disabled
- failure_taxonomy: agent_patch_wrong, subagent_noise_or_unused, audit_unclean
- evidence_gate_failures: none
- e3_gate_failures: e3_human_review_not_completed

## Pair 4
- pair_report: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-004\pair-report.md
- audit_manifest: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-004\audit.json
- reported_evidence_level: E3-candidate
- included_in_utility_aggregate: False
- included_in_e3_aggregate: False
- human_review_completed: False
- human_review_decision: 
- human_review_disagreement: False
- utility_direction: score_disabled
- failure_taxonomy: agent_patch_wrong, subagent_noise_or_unused, audit_unclean
- evidence_gate_failures: none
- e3_gate_failures: e3_human_review_not_completed

## Pair 5
- pair_report: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-005\pair-report.md
- audit_manifest: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\log-summary\runs\terminal_bench__log-summary\20260616-025659-816\pair-005\audit.json
- reported_evidence_level: E3-candidate
- included_in_utility_aggregate: False
- included_in_e3_aggregate: False
- human_review_completed: False
- human_review_decision: 
- human_review_disagreement: False
- utility_direction: score_disabled
- failure_taxonomy: agent_patch_wrong, subagent_noise_or_unused, audit_unclean
- evidence_gate_failures: none
- e3_gate_failures: e3_human_review_not_completed
