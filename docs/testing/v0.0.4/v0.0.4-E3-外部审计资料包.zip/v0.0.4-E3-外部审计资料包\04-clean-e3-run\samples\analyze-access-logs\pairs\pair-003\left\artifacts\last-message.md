The report `/app/report.txt` has been created with the correct formatting. Here's a summary of the results:

| Metric | Value |
|---|---|
| **Total requests** | 2000 |
| **Unique IP addresses** | 273 |
| **Top URL** | `/order-confirmation` (54 hits) |
| **2nd URL** | `/product/456` (53 hits) |
| **3rd URL** | `/about.html` (52 hits) |
| **404 errors** | 83 |

The file content is exactly:

```
Total requests: 2000
Unique IP addresses: 273
Top 3 URLs:
  /order-confirmation: 54
  /product/456: 53
  /about.html: 52
404 errors: 83
```