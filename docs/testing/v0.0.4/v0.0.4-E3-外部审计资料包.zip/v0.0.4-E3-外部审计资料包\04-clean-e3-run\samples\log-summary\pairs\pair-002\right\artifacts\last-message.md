The task is complete. Here's a summary of the results:

| Severity | Total Lines (across all `.log` files) |
|----------|---------------------------------------|
| **ERROR**   | 4 |
| **WARNING** | 3 |
| **INFO**    | 8 |

**Breakdown by file:**
- `app1.log` — 2 ERROR, 1 WARNING, 2 INFO
- `app2.log` — 1 ERROR, 1 WARNING, 3 INFO
- `db.log`    — 1 ERROR, 1 WARNING, 3 INFO

The output has been written to `W:\app\summary.csv` with the exact format requested (header + 3 data lines).