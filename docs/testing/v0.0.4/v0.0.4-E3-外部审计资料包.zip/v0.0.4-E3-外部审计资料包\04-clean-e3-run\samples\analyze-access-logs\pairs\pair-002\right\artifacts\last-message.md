报告已生成在 `/app/report.txt`（即 `W:\app\report.txt`）。以下是摘要内容：

| 指标 | 结果 |
|---|---|
| **Total requests** | 2000 |
| **Unique IP addresses** | 273 |
| **Top 1 URL** | `/order-confirmation` — 54 次 |
| **Top 2 URL** | `/product/456` — 53 次 |
| **Top 3 URL** | `/about.html` — 52 次 |
| **404 errors** | 83 |

文件格式完全符合要求：
```
Total requests: 2000
Unique IP addresses: 273
Top 3 URLs:
  /order-confirmation: 54
  /product/456: 53
  /about.html: 52
404 errors: 83
```