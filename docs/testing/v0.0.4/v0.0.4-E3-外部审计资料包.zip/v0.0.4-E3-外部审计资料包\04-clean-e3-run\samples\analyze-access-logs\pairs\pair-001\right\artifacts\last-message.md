The report has been successfully created at **`W:\app\report.txt`** with all required statistics.

**Summary of work completed:**

1. **Read** the web server access log (`access_log`, 2000 lines, 167KB)
2. **Computed** the four requested metrics:
   - **Total requests:** 2000
   - **Unique IP addresses:** 273
   - **Top 3 URLs:**
     - `/order-confirmation`: 54 requests
     - `/product/456`: 53 requests
     - `/about.html`: 52 requests
   - **404 errors:** 83
3. **Wrote** `report.txt` with the exact specified format
4. **Validated** the output via an independent validation script — all 7 lines confirmed correct

**Deliverable:** `W:\app\report.txt` (or `/app/report.txt` relative to the working directory)

```
Total requests: 2000
Unique IP addresses: 273
Top 3 URLs:
  /order-confirmation: 54
  /product/456: 53
  /about.html: 52
404 errors: 83
```