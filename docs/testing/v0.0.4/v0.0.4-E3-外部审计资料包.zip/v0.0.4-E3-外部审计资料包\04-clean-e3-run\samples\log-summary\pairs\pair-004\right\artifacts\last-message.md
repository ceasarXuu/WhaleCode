Done. Here's a summary of what was found:

| Severity | Count |
|----------|-------|
| **ERROR** | 4 |
| **WARNING** | 3 |
| **INFO** | 8 |

**Scanned files:** `app1.log`, `app2.log`, `db.log` (3 log files total in `W:\app\logs\`)

**Output written to:** `W:\app\summary.csv` — valid CSV with header row + one row per severity level.