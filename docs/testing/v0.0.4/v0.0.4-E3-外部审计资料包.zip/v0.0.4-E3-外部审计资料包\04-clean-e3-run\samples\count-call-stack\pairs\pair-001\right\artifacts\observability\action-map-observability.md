﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-001\right\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-001\right\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-001\right\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 3
- edges: 2
- agents: 0
- collab tool calls: 0
- map runtime events: 89
- output contracts: 1
- fact sources: 1
- accepted results: 2
- questioned/invalid results: 0
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: True
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: none
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=1 |  |
| required_fact_source_missing | True | at least one fact source | factSources=1 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=13, resultWithClaimEvidence=2 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=13, validityTransitions=2 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | True | each final artifact path resolves to a SHA-256 hash | missingHash=0 |  |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 1 |
| factSourceCount | 1 |
| activeFactCount | 0 |
| resultCount | 13 |
| acceptedResultCount | 2 |
| questionedOrInvalidResultCount | 0 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 2 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 2 |
| cognitiveStateUpdateCount | 20 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 0 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Analyze stack traces from profiling log | Parse a log file containing stack traces, identify unique call sites based on top 3 frames, compute frequency, and output top 10 to output.txt | 1 | 1 | 0 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-1 | inspect_code_context | Find and inspect the log file | completed | 0 | 7 | 1 | 0 | 1 | 0 |
| node-2 | implement_solution | Parse stack traces and generate output.txt | completed | 0 | 4 | 1 | 0 | 0 | 0 |
| node-3 | final_synthesis | Final summary of stack trace analysis | blocked | 0 | 2 | 0 | 0 | 0 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:output.txt | task-1 | output.txt | 1ce2025ef73980c0 | result-11 | oc-1 | c-2, c-3 | artifactRef=W:\app\log_extracted\log.stack, artifactRef=W:\app\output.txt |  |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | unreviewed |  |  |  |  |
| result-4 | node-1 | unreviewed |  |  |  |  |
| result-5 | node-1 | unreviewed |  |  |  |  |
| result-6 | node-1 | unreviewed |  |  |  |  |
| result-7 | node-1 | accepted | c-1 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\log_extracted\\log.stack","validatorRef":null} |  | Inspected log.stack file format - confirmed structure with count lines followed by tab-indented frame lines, 26712 lines total, ~4MB file |
| result-8 | node-2 | unreviewed |  |  |  |  |
| result-9 | node-2 | unreviewed |  |  |  |  |
| result-10 | node-2 | unreviewed |  |  |  |  |
| result-11 | node-2 | accepted | c-2, c-3 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\output.txt","validatorRef":null} |  | Script successfully parsed all 646 trace entries, computed 318 unique call sites weighted by occurrence counts, and wrote top 10 to output.txt. File verified. |
| result-12 | node-3 | unreviewed |  |  |  |  |
| result-13 | node-3 | unreviewed |  |  |  |  |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-2 | node-3 |

## Timeline

- 2026-06-15T19:43:00.714Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T19:43:04.656Z **task_created** task created: task-1 Analyze stack traces from profiling log
- 2026-06-15T19:43:04.657Z **map_created** map created: map-1 Analyze stack traces from profiling log
- 2026-06-15T19:43:04.657Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:43:04.658Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:43:04.658Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:43:04.659Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T19:43:04.659Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T19:43:04.660Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T19:43:04.660Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:43:10.629Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T19:43:10.629Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:43:10.630Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T19:43:10.631Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:43:10.632Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:43:10.632Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:43:10.632Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:43:10.633Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:43:18.194Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T19:43:18.197Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T19:43:18.198Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:43:24.897Z **node_result_recorded** node result recorded: node-1 / result-2 action=read
- 2026-06-15T19:43:24.898Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T19:43:24.898Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:43:30.444Z **node_result_recorded** node result recorded: node-1 / result-3 action=read
- 2026-06-15T19:43:30.444Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-3 tags=tool_success
- 2026-06-15T19:43:30.445Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:43:38.610Z **node_result_recorded** node result recorded: node-1 / result-4 action=read
- 2026-06-15T19:43:38.611Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-4 tags=tool_success
- 2026-06-15T19:43:38.611Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:43:49.303Z **node_result_recorded** node result recorded: node-1 / result-5 action=read
- 2026-06-15T19:43:49.304Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-5 tags=tool_success
- 2026-06-15T19:43:49.304Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:43:56.567Z **node_result_recorded** node result recorded: node-1 / result-6 action=read
- 2026-06-15T19:43:56.568Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-6 tags=tool_success
- 2026-06-15T19:43:56.569Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:44:07.780Z **tool_action_blocked** tool action blocked: node-1 edit via shell_command
- 2026-06-15T19:44:07.780Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:44:11.475Z **node_result_recorded** node result recorded: node-1 / result-7
- 2026-06-15T19:44:11.476Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T19:44:11.476Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T19:44:11.476Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T19:44:11.477Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T19:44:11.477Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T19:44:11.477Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:44:14.407Z **result_validity_changed** result validity: result-7 -> accepted
- 2026-06-15T19:44:14.407Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:44:25.718Z **node_result_recorded** node result recorded: node-2 / result-8 action=edit
- 2026-06-15T19:44:25.719Z **taskspace_trace_event_recorded** trace event: trace-7 result=result-8 tags=tool_failure
- 2026-06-15T19:44:25.719Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:44:34.957Z **node_result_recorded** node result recorded: node-2 / result-9 action=edit
- 2026-06-15T19:44:34.957Z **taskspace_trace_event_recorded** trace event: trace-8 result=result-9 tags=tool_success
- 2026-06-15T19:44:34.958Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:44:39.885Z **node_result_recorded** node result recorded: node-2 / result-10 action=read
- 2026-06-15T19:44:39.885Z **taskspace_trace_event_recorded** trace event: trace-9 result=result-10 tags=tool_success
- 2026-06-15T19:44:39.886Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T19:44:49.515Z **node_result_recorded** node result recorded: node-2 / result-11
- 2026-06-15T19:44:49.515Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T19:44:49.516Z **node_status_changed** node status: node-2 running -> completed
- 2026-06-15T19:44:49.516Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T19:44:49.516Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T19:44:49.517Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T19:44:49.517Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:44:54.664Z **result_validity_changed** result validity: result-11 -> accepted
- 2026-06-15T19:44:54.664Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:44:54.666Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T19:44:54.667Z **cognitive_state_updated** cognitive state updated: result_adoption.decision result-7
- 2026-06-15T19:44:54.667Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:44:58.936Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:44:58.937Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:44:58.937Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:44:58.937Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:45:03.713Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:45:03.713Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:45:03.714Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:45:03.714Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:45:10.693Z **node_result_recorded** node result recorded: node-3 / result-12 action=read
- 2026-06-15T19:45:10.694Z **taskspace_trace_event_recorded** trace event: trace-10 result=result-12 tags=tool_success
- 2026-06-15T19:45:10.694Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:45:12.743Z **cognitive_state_updated** cognitive state updated: result_adoption result-11
- 2026-06-15T19:45:12.743Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:45:17.205Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:45:17.205Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:45:17.206Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:45:17.206Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T19:45:28.951Z **node_result_recorded** node result recorded: node-3 / result-13
- 2026-06-15T19:45:28.951Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T19:45:28.952Z **node_status_changed** node status: node-3 running -> blocked
- 2026-06-15T19:45:28.952Z **snapshot_updated** snapshot updated: maps=1 nodes=3

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
