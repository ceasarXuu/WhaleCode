﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-003\right\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-003\right\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-003\right\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 4
- edges: 3
- agents: 0
- collab tool calls: 0
- map runtime events: 137
- output contracts: 1
- fact sources: 1
- accepted results: 3
- questioned/invalid results: 0
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: False
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: final_artifact_hash_missing
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=1 |  |
| required_fact_source_missing | True | at least one fact source | factSources=1 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=23, resultWithClaimEvidence=3 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=23, validityTransitions=4 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | False | each final artifact path resolves to a SHA-256 hash | missingHash=1 | task:task-1\|artifact:W:\app\output.txt |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 1 |
| factSourceCount | 1 |
| activeFactCount | 0 |
| resultCount | 23 |
| acceptedResultCount | 3 |
| questionedOrInvalidResultCount | 0 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 3 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 4 |
| cognitiveStateUpdateCount | 17 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 1 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Analyze profiling stack traces | Parse a log file of stack traces, identify unique call sites based on top 3 frames, compute occurrence counts, and output the top 10 to /app/output.txt | 1 | 1 | 0 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-2 | implement_solution | Parse log file and generate output.txt | completed | 0 | 10 | 1 | 0 | 4 | 0 |
| node-1 | inspect_code_context | Inspect log file and understand structure | completed | 0 | 7 | 1 | 0 | 1 | 0 |
| node-4 | final_synthesis | Final summary of stack trace analysis | blocked | 0 | 1 | 0 | 0 | 0 | 0 |
| node-3 | smoke_test | Validate output.txt format and content | blocked | 0 | 5 | 1 | 0 | 2 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:W:\app\output.txt | task-1 | W:\app\output.txt |  | result-17, result-22 | oc-1 | cl-5, cl-6, cl-7 | artifactRef=W:\app\output.txt | Get-Content line-by-line check |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-8 | node-2 | unreviewed |  |  |  |  |
| result-9 | node-2 | unreviewed |  |  |  |  |
| result-10 | node-2 | unreviewed |  |  |  |  |
| result-11 | node-2 | unreviewed |  |  |  |  |
| result-12 | node-2 | unreviewed |  |  |  |  |
| result-13 | node-2 | unreviewed |  |  |  |  |
| result-14 | node-2 | unreviewed |  |  |  |  |
| result-15 | node-2 | unreviewed |  |  |  |  |
| result-16 | node-2 | unreviewed |  |  |  |  |
| result-17 | node-2 | accepted | cl-5, cl-6 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\output.txt","validatorRef":null} |  | Validation passed: output.txt format matches spec exactly, 10 entries sorted descending, all Frame 1/2/3 lines present |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | unreviewed |  |  |  |  |
| result-4 | node-1 | unreviewed |  |  |  |  |
| result-5 | node-1 | unreviewed |  |  |  |  |
| result-6 | node-1 | unreviewed |  |  |  |  |
| result-7 | node-1 | accepted | cl-1, cl-2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\log.stack","validatorRef":null} |  | Inspected log.stack - file exists with 26712 lines, format confirmed: count number followed by tab-indented frames with 'in' prefix |
| result-23 | node-4 | unreviewed |  |  |  |  |
| result-18 | node-3 | unreviewed |  |  |  |  |
| result-19 | node-3 | unreviewed |  |  |  |  |
| result-20 | node-3 | unreviewed |  |  |  |  |
| result-21 | node-3 | unreviewed |  |  |  |  |
| result-22 | node-3 | accepted | cl-7 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\output.txt","validatorRef":"Get-Content line-by-line check"} | Get-Content line-by-line check | Blocked smoke_test node: validation already performed and passed via Get-Content inspection showing correct header, 10 entries, descending counts. |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-2 | node-3 |
| node-2 | node-4 |

## Timeline

- 2026-06-15T19:59:26.511Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T19:59:29.709Z **task_created** task created: task-1 Analyze profiling stack traces
- 2026-06-15T19:59:29.709Z **map_created** map created: map-1 Analyze profiling stack traces
- 2026-06-15T19:59:29.710Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T19:59:29.710Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T19:59:29.710Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T19:59:29.711Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:59:35.909Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T19:59:35.909Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T19:59:35.910Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T19:59:35.910Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T19:59:35.910Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:59:35.911Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T19:59:35.912Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:59:35.912Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T19:59:35.913Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:59:41.887Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T19:59:41.888Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T19:59:41.888Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:59:46.921Z **node_result_recorded** node result recorded: node-1 / result-2 action=read
- 2026-06-15T19:59:46.922Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T19:59:46.922Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:59:51.775Z **node_result_recorded** node result recorded: node-1 / result-3 action=read
- 2026-06-15T19:59:51.776Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-3 tags=tool_success
- 2026-06-15T19:59:51.777Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T19:59:56.094Z **node_result_recorded** node result recorded: node-1 / result-4 action=read
- 2026-06-15T19:59:56.095Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-4 tags=tool_success
- 2026-06-15T19:59:56.096Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:00:00.473Z **node_result_recorded** node result recorded: node-1 / result-5 action=read
- 2026-06-15T20:00:00.474Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-5 tags=tool_success
- 2026-06-15T20:00:00.474Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:00:06.554Z **tool_action_blocked** tool action blocked: node-1 unknown via shell_command
- 2026-06-15T20:00:06.554Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:00:09.607Z **node_result_recorded** node result recorded: node-1 / result-6 action=read
- 2026-06-15T20:00:09.608Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-6 tags=tool_success
- 2026-06-15T20:00:09.608Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:00:14.448Z **node_result_recorded** node result recorded: node-1 / result-7
- 2026-06-15T20:00:14.449Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T20:00:14.449Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T20:00:14.449Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T20:00:14.450Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T20:00:14.450Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T20:00:14.450Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:00:21.732Z **result_validity_changed** result validity: result-7 -> accepted
- 2026-06-15T20:00:21.733Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:00:29.206Z **node_result_recorded** node result recorded: node-2 / result-8 action=read
- 2026-06-15T20:00:29.207Z **taskspace_trace_event_recorded** trace event: trace-7 result=result-8 tags=tool_success
- 2026-06-15T20:00:29.207Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:00:29.240Z **node_result_recorded** node result recorded: node-2 / result-9 action=read
- 2026-06-15T20:00:29.241Z **taskspace_trace_event_recorded** trace event: trace-8 result=result-9 tags=tool_success
- 2026-06-15T20:00:29.241Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:00:46.283Z **node_result_recorded** node result recorded: node-2 / result-10 action=edit
- 2026-06-15T20:00:46.283Z **taskspace_trace_event_recorded** trace event: trace-9 result=result-10 tags=tool_success
- 2026-06-15T20:00:46.284Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:01:18.506Z **tool_action_blocked** tool action blocked: node-2 unknown via shell_command
- 2026-06-15T20:01:18.506Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:01:23.503Z **tool_action_blocked** tool action blocked: node-2 unknown via shell_command
- 2026-06-15T20:01:23.503Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:01:28.183Z **node_result_recorded** node result recorded: node-2 / result-11 action=edit
- 2026-06-15T20:01:28.183Z **taskspace_trace_event_recorded** trace event: trace-10 result=result-11 tags=tool_success
- 2026-06-15T20:01:28.184Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:01:29.867Z **tool_action_blocked** tool action blocked: node-2 unknown via shell_command
- 2026-06-15T20:01:29.867Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:01:37.837Z **node_result_recorded** node result recorded: node-2 / result-12 action=read
- 2026-06-15T20:01:37.838Z **taskspace_trace_event_recorded** trace event: trace-11 result=result-12 tags=tool_success
- 2026-06-15T20:01:37.838Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:01:39.342Z **tool_action_blocked** tool action blocked: node-2 unknown via shell_command
- 2026-06-15T20:01:39.342Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:01:44.168Z **node_result_recorded** node result recorded: node-2 / result-13 action=edit
- 2026-06-15T20:01:44.169Z **taskspace_trace_event_recorded** trace event: trace-12 result=result-13 tags=tool_success
- 2026-06-15T20:01:44.170Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:01:51.356Z **node_result_recorded** node result recorded: node-2 / result-14 action=edit
- 2026-06-15T20:01:51.357Z **taskspace_trace_event_recorded** trace event: trace-13 result=result-14 tags=tool_success
- 2026-06-15T20:01:51.357Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:01:55.802Z **node_result_recorded** node result recorded: node-2 / result-15 action=read
- 2026-06-15T20:01:55.802Z **taskspace_trace_event_recorded** trace event: trace-14 result=result-15 tags=tool_success
- 2026-06-15T20:01:55.803Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:02:05.456Z **node_result_recorded** node result recorded: node-2 / result-16 action=edit
- 2026-06-15T20:02:05.457Z **taskspace_trace_event_recorded** trace event: trace-15 result=result-16 tags=tool_failure
- 2026-06-15T20:02:05.457Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:02:08.147Z **node_result_recorded** node result recorded: node-2 / result-17
- 2026-06-15T20:02:08.148Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T20:02:08.148Z **node_status_changed** node status: node-2 running -> completed
- 2026-06-15T20:02:08.149Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T20:02:08.149Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T20:02:08.149Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T20:02:08.149Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:02:11.417Z **result_validity_changed** result validity: result-17 -> accepted
- 2026-06-15T20:02:11.418Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:02:16.369Z **tool_action_blocked** tool action blocked: node-3 edit via shell_command
- 2026-06-15T20:02:16.370Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:02:20.877Z **node_result_recorded** node result recorded: node-3 / result-18 action=read
- 2026-06-15T20:02:20.877Z **taskspace_trace_event_recorded** trace event: trace-16 result=result-18 tags=tool_success
- 2026-06-15T20:02:20.878Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:02:25.366Z **node_result_recorded** node result recorded: node-3 / result-19 action=read
- 2026-06-15T20:02:25.366Z **taskspace_trace_event_recorded** trace event: trace-17 result=result-19 tags=tool_success
- 2026-06-15T20:02:25.367Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:02:30.018Z **node_result_recorded** node result recorded: node-3 / result-20 action=read
- 2026-06-15T20:02:30.019Z **taskspace_trace_event_recorded** trace event: trace-18 result=result-20 tags=tool_success
- 2026-06-15T20:02:30.019Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:02:34.183Z **tool_action_blocked** tool action blocked: node-3 edit via shell_command
- 2026-06-15T20:02:34.183Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:02:43.916Z **node_result_recorded** node result recorded: node-3 / result-21 action=read
- 2026-06-15T20:02:43.916Z **taskspace_trace_event_recorded** trace event: trace-19 result=result-21 tags=tool_success
- 2026-06-15T20:02:43.917Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:02:49.249Z **result_validity_changed** result validity: result-17 -> accepted
- 2026-06-15T20:02:49.250Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:02:56.369Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:02:56.369Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:02:56.370Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:02:56.370Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T20:02:56.370Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:03:01.214Z **node_result_recorded** node result recorded: node-3 / result-22
- 2026-06-15T20:03:01.214Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T20:03:01.215Z **node_status_changed** node status: node-3 running -> blocked
- 2026-06-15T20:03:01.215Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:03:03.275Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T20:03:03.275Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T20:03:03.275Z **lease_created** lease created: lease-4 on node-4
- 2026-06-15T20:03:03.276Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:03:06.335Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T20:03:06.335Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:03:11.344Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:03:11.344Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:03:11.345Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:03:11.345Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T20:03:11.345Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:03:19.305Z **result_validity_changed** result validity: result-22 -> accepted
- 2026-06-15T20:03:19.306Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:03:24.572Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-complete
- 2026-06-15T20:03:24.572Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:03:29.189Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final
- 2026-06-15T20:03:29.189Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:03:33.544Z **node_result_recorded** node result recorded: node-4 / result-23
- 2026-06-15T20:03:33.544Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T20:03:33.545Z **node_status_changed** node status: node-4 running -> blocked
- 2026-06-15T20:03:33.545Z **snapshot_updated** snapshot updated: maps=1 nodes=4

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
