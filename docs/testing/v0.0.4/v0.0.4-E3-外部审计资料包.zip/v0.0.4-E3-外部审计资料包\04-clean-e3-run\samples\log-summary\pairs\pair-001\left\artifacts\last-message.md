Done. The file `W:\app\summary.csv` has been created with the correct structure:

| severity | count |
|----------|-------|
| ERROR    | 4     |
| WARNING  | 3     |
| INFO     | 8     |

**Summary of log scanning across 3 files (app1.log, app2.log, db.log):**
- **ERROR** lines: 4 (app1: 2, app2: 1, db: 1)
- **WARNING** lines: 3 (app1: 1, app2: 1, db: 1)
- **INFO** lines: 8 (app1: 2, app2: 3, db: 3)