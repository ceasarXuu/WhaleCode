﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\left\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\left\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\left\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 1
- nodes: 4
- edges: 3
- agents: 0
- collab tool calls: 0
- map runtime events: 119
- output contracts: 1
- fact sources: 3
- accepted results: 3
- questioned/invalid results: 0
- final artifacts: 1
- cognitive structural gate: True
- cognitive hard gate: False
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: final_artifact_hash_missing
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=1 |  |
| required_fact_source_missing | True | at least one fact source | factSources=3 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=11, resultWithClaimEvidence=3 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=11, validityTransitions=3 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | True | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=0 |  |
| final_artifact_hash_missing | False | each final artifact path resolves to a SHA-256 hash | missingHash=1 | task:task-1\|artifact:W:\app\report.txt |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 1 |
| factSourceCount | 3 |
| activeFactCount | 1 |
| resultCount | 11 |
| acceptedResultCount | 3 |
| questionedOrInvalidResultCount | 0 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 3 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 3 |
| cognitiveStateUpdateCount | 39 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 1 |
| finalArtifactMissingHashCount | 1 |
| finalArtifactMissingWhyChainCount | 0 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-1 | active | Analyze web server access log | Read /app/access_log, compute summary statistics, and write /app/report.txt with total requests, unique IPs, top 3 URLs, and 404 error count. | 1 | 3 | 1 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-2 | implement_solution | Analyze access log and write report | completed | 0 | 5 | 1 | 0 | 0 | 0 |
| node-1 | inspect_code_context | Inspect access log and generate report | completed | 0 | 2 | 1 | 0 | 3 | 0 |
| node-4 | final_synthesis | Summarize access log analysis results | completed | 0 | 1 | 0 | 0 | 0 | 0 |
| node-3 | smoke_test | Validate report format and content | blocked | 0 | 3 | 1 | 0 | 0 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:W:\app\report.txt | task-1 | W:\app\report.txt |  | result-7, result-10 | oc-1 | cl-3, cl-4, cl-5, cl-6, cl-8 | artifactRef=W:\app\access_log, artifactRef=W:\app\report.txt, validatorRef=PowerShell comparison - exit code 0, validatorRef=PowerShell comparison | PowerShell comparison - exit code 0, PowerShell comparison |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-3 | node-2 | unreviewed |  |  |  |  |
| result-4 | node-2 | unreviewed |  |  |  |  |
| result-5 | node-2 | unreviewed |  |  |  |  |
| result-6 | node-2 | unreviewed |  |  |  |  |
| result-7 | node-2 | accepted | cl-3, cl-4, cl-5, cl-6 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\access_log","validatorRef":null} |  | Successfully read access_log, computed all 4 required statistics, and wrote report.txt with correct format. Numbers verified by PowerShell computation. |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | accepted | cl-1, cl-2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\access_log","validatorRef":null} |  | Successfully read access_log and confirmed log format. The format matches standard Apache combined log format which will allow parsing for all required statistics. |
| result-11 | node-4 | unreviewed |  |  |  |  |
| result-8 | node-3 | unreviewed |  |  |  |  |
| result-9 | node-3 | unreviewed |  |  |  |  |
| result-10 | node-3 | accepted | cl-8 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:\\app\\report.txt","validatorRef":null}<br>{"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":null,"validatorRef":"PowerShell comparison"} |  | Validation test passed with exit code 0. All report content verified correct. |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-2 | node-3 |
| node-2 | node-4 |

## Timeline

- 2026-06-15T18:33:33.955Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T18:33:37.298Z **task_created** task created: task-1 Analyze web server access log
- 2026-06-15T18:33:37.299Z **map_created** map created: map-1 Analyze web server access log
- 2026-06-15T18:33:37.299Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T18:33:37.300Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T18:33:37.300Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T18:33:37.301Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:33:42.930Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:33:42.930Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:33:42.931Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:33:42.931Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:33:42.932Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:33:42.932Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-6
- 2026-06-15T18:33:42.932Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:33:42.933Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T18:33:42.934Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:33:42.935Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-1
- 2026-06-15T18:33:42.935Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:33:44.882Z **tool_action_blocked** tool action blocked: node-1 unknown via shell_command
- 2026-06-15T18:33:44.883Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:33:49.058Z **tool_action_blocked** tool action blocked: node-1 unknown via shell_command
- 2026-06-15T18:33:49.060Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:33:54.604Z **tool_action_blocked** tool action blocked: node-1 unknown via shell_command
- 2026-06-15T18:33:54.605Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:34:00.491Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-2
- 2026-06-15T18:34:00.491Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:34:06.305Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact fact-1
- 2026-06-15T18:34:06.305Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:34:18.128Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T18:34:18.129Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T18:34:18.130Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T18:34:22.133Z **node_result_recorded** node result recorded: node-1 / result-2
- 2026-06-15T18:34:22.134Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T18:34:22.134Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T18:34:22.134Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T18:34:22.135Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T18:34:22.135Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T18:34:22.135Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:34:26.367Z **result_validity_changed** result validity: result-2 -> accepted
- 2026-06-15T18:34:26.368Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:34:30.930Z **node_result_recorded** node result recorded: node-2 / result-3 action=read
- 2026-06-15T18:34:30.931Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-3 tags=tool_success
- 2026-06-15T18:34:30.931Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:34:43.399Z **node_result_recorded** node result recorded: node-2 / result-4 action=read
- 2026-06-15T18:34:43.400Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-4 tags=tool_success
- 2026-06-15T18:34:43.400Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:34:50.398Z **node_result_recorded** node result recorded: node-2 / result-5 action=edit
- 2026-06-15T18:34:50.399Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-5 tags=tool_success
- 2026-06-15T18:34:50.400Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:34:55.472Z **node_result_recorded** node result recorded: node-2 / result-6 action=read
- 2026-06-15T18:34:55.472Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-6 tags=tool_success
- 2026-06-15T18:34:55.473Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T18:34:59.148Z **node_result_recorded** node result recorded: node-2 / result-7
- 2026-06-15T18:34:59.148Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T18:34:59.149Z **node_status_changed** node status: node-2 running -> completed
- 2026-06-15T18:34:59.149Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T18:34:59.149Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T18:34:59.150Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T18:34:59.150Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:35:02.190Z **result_validity_changed** result validity: result-7 -> accepted
- 2026-06-15T18:35:02.190Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:35:07.899Z **node_result_recorded** node result recorded: node-3 / result-8 action=read
- 2026-06-15T18:35:07.900Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-8 tags=tool_success
- 2026-06-15T18:35:07.901Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:35:21.193Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:35:21.194Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:35:21.194Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:35:21.195Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:35:21.195Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:35:21.195Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-6
- 2026-06-15T18:35:21.196Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:35:26.403Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-3
- 2026-06-15T18:35:26.403Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:35:37.207Z **node_result_recorded** node result recorded: node-3 / result-9 action=read
- 2026-06-15T18:35:37.208Z **taskspace_trace_event_recorded** trace event: trace-7 result=result-9 tags=tool_success
- 2026-06-15T18:35:37.208Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:35:43.975Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T18:35:43.975Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:35:51.915Z **node_result_recorded** node result recorded: node-3 / result-10
- 2026-06-15T18:35:51.916Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T18:35:51.916Z **node_status_changed** node status: node-3 running -> blocked
- 2026-06-15T18:35:51.917Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T18:35:53.685Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T18:35:53.686Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T18:35:53.686Z **lease_created** lease created: lease-4 on node-4
- 2026-06-15T18:35:53.687Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:35:56.967Z **result_validity_changed** result validity: result-10 -> accepted
- 2026-06-15T18:35:56.967Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:36:04.161Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-2
- 2026-06-15T18:36:04.161Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:36:09.981Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:36:09.981Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:36:09.982Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:36:09.982Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:36:09.982Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:36:09.983Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-6
- 2026-06-15T18:36:09.983Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:36:20.473Z **cognitive_state_updated** cognitive state updated: result_adoption result-7
- 2026-06-15T18:36:20.473Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:36:26.389Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s1
- 2026-06-15T18:36:26.389Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s2
- 2026-06-15T18:36:26.390Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s3
- 2026-06-15T18:36:26.390Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s4
- 2026-06-15T18:36:26.390Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s5
- 2026-06-15T18:36:26.391Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s6
- 2026-06-15T18:36:26.391Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:36:30.953Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T18:36:30.953Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T18:36:30.954Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T18:36:30.954Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-4
- 2026-06-15T18:36:30.954Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-5
- 2026-06-15T18:36:30.955Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-6
- 2026-06-15T18:36:30.955Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:36:36.957Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final
- 2026-06-15T18:36:36.957Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T18:36:44.712Z **node_result_recorded** node result recorded: node-4 / result-11
- 2026-06-15T18:36:44.713Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T18:36:44.713Z **node_status_changed** node status: node-4 running -> completed
- 2026-06-15T18:36:44.713Z **snapshot_updated** snapshot updated: maps=1 nodes=4

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
