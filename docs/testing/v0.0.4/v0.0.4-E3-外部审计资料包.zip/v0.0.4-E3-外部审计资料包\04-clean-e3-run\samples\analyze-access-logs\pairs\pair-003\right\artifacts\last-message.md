Report generated successfully at **`/app/report.txt`** with the following contents:

```
Total requests: 2000
Unique IP addresses: 273
Top 3 URLs:
  /order-confirmation: 54
  /product/456: 53
  /about.html: 52
404 errors: 83
```

**Summary of the analysis:**

| Metric | Value |
|---|---|
| **Total requests** | 2,000 |
| **Unique IP addresses** | 273 |
| **Most requested URL** | `/order-confirmation` (54 times) |
| **2nd most requested URL** | `/product/456` (53 times) |
| **3rd most requested URL** | `/about.html` (52 times) |
| **404 errors** | 83 |

**Process:**
1. Read the 2,000-line Apache CLF access log at `W:\app\access_log`
2. Parsed each line using regex to extract IP address, request URL, and HTTP status code
3. Computed aggregates (total, unique IPs, URL frequency ranking, 404 count)
4. Wrote the formatted report to `W:\app\report.txt`
5. Validated every line of the output to confirm correctness

All format and content checks passed.