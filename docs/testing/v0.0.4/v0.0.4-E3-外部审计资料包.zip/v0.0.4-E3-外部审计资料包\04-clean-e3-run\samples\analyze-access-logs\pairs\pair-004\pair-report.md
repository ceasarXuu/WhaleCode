﻿# TaskSpace Benchmark Pair Report

- scenario: terminal_bench__analyze-access-logs
- level: L3
- requested_evidence_target: E3
- reported_evidence_level: E3-candidate
- oracle_isolation_policy: deferred_materialization_allowed
- valid_pair: True
- included_in_utility_aggregate: False
- left_logical_mode: taskspace
- right_logical_mode: standard
- included_in_e3_aggregate: False

## Evidence Gate Failures
- none
- audit_manifest_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\audit.json
- utility_direction: score_disabled
- failure_taxonomy: audit_unclean
- run_score_ready: False
- run_score_valid: False
- audit_required: True
- engineering_unclean: False
- engineering_unclean_reasons: none
- outcome_standard: solved
- outcome_taskspace: solved
- pair_timing_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\pair-timing.json

## Harness Health / Abort
- pretest_failure_sides: none
- infra_signatures: none
- left_validation_lifecycle_stage: tests_completed
- left_tests_started_seen: True
- right_validation_lifecycle_stage: tests_completed
- right_tests_started_seen: True

## E3 Gate
- sample_origin_type: external_benchmark
- human_review_required: True
- human_review_completed: False
- human_review_decision: score_disabled
- score_valid: False
- human_review_disagreement: False
- e3_minimum_repeats: 5
- claim_scope: Terminal-Bench coding/file/debug/data-processing subset
- declared_validator_runtime: terminal_bench_equivalent_docker_app
- declared_official_runner_or_equivalent: True
- declared_agent_cannot_read_validator_source: True
- declared_validator_e3_eligible: True
- declared_validator_downgrade_reason: 
- e3_human_review_not_completed
- external_runtime_proof_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\external-runtime-proof.json
- external_runner_equivalence_proof_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\external-runner-equivalence-proof.json
- external_isolation_proof_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\external-isolation-proof.json
- external_combined_proof_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\external-e3-proof.json
- proof_official_runner_or_equivalent: True
- proof_agent_cannot_read_validator_source: True
- proof_validator_e3_eligible: True
- audit_review_source_path: 
- audit_review_failures: audit_review_missing

## Variable Control
- failures: none

## Prompt Guard
- invalid_prompt: False
- manual_review_required: False
- hard_hits: 
- context_hits: 

## Oracle Isolation Probe
- oracle_isolation_level: hard_deferred_materialization
- canary_leaked: False
- canary_materialized_during_probe: False
- path_mentioned: True
- jsonl: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\oracle-isolation-probe\whale-exec.jsonl

## Scenario Warnings
- none

## Utility Assessment
- outcome: score_disabled
- score_valid: False
- taskspace_tool_call_ratio: 1.75
- taskspace_wall_time_ratio: 5.66
- taskspace_tool_call_ratio_warn: False
- taskspace_wall_time_ratio_warn: False
- note: score fields disabled because engineering clean execution is not established; raw side outcomes are diagnostic only.

## left / taskspace
- business_success: True
- exec_exit_code: 0
- exec_timed_out: False
- public_validation_exit_code: 0
- hidden_oracle_exit_code: 0
- oracle_isolation_level: hard_sandbox
- wall_time_ms: 192157
- tool_call_count: 7
- changed_paths: report.txt
- changed_file_inventory: report.txt[??] sha256=b496c293730d89cece73378be3e6d72efdac5fc234eedcf53c3c29cf5a0ecd6a size=137
- metrics_warnings: 
- metrics_taints: 
- validator_environment_failures: 
- docker_build_result_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\left\artifacts\vrun\docker-build-result.json
- validator_environment_mismatch: False
- maps: 1
- nodes: 4
- edges: 3
- edge_order_violations: 0
- spawn_agent_calls: 0
- subagent_results: 0
- open_leaf_nodes: 0
- ordinary_before_binding: False

## right / standard
- business_success: True
- exec_exit_code: 0
- exec_timed_out: False
- public_validation_exit_code: 0
- hidden_oracle_exit_code: 0
- oracle_isolation_level: hard_sandbox
- wall_time_ms: 33931
- tool_call_count: 4
- changed_paths: report.txt
- changed_file_inventory: report.txt[??] sha256=7ab2a6e328679b257b8e5c6b4dc131241b8761aa8dbf79130b1c69ca7434433d size=143
- metrics_warnings: 
- metrics_taints: 
- validator_environment_failures: 
- docker_build_result_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\analyze-access-logs\runs\terminal_bench__analyze-access-logs\20260616-020723-919\pair-004\right\artifacts\vrun\docker-build-result.json
- validator_environment_mismatch: False
- maps: 0
- nodes: 0
- edges: 0
- edge_order_violations: 0
- spawn_agent_calls: 0
- subagent_results: 0
- open_leaf_nodes: 0
- ordinary_before_binding: False
