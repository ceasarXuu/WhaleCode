﻿# TaskSpace Benchmark Pair Report

- scenario: terminal_bench__count-call-stack
- level: L3
- requested_evidence_target: E3
- reported_evidence_level: E1
- oracle_isolation_policy: deferred_materialization_allowed
- valid_pair: True
- included_in_utility_aggregate: False
- left_logical_mode: taskspace
- right_logical_mode: standard
- included_in_e3_aggregate: False

## Evidence Gate Failures
- business_success_false
- audit_manifest_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\audit.json
- utility_direction: score_disabled
- failure_taxonomy: agent_patch_wrong, audit_unclean
- run_score_ready: False
- run_score_valid: False
- audit_required: True
- engineering_unclean: False
- engineering_unclean_reasons: none
- outcome_standard: wrong
- outcome_taskspace: wrong
- pair_timing_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\pair-timing.json

## Harness Health / Abort
- pretest_failure_sides: none
- infra_signatures: none
- left_validation_lifecycle_stage: tests_completed
- left_tests_started_seen: True
- right_validation_lifecycle_stage: tests_completed
- right_tests_started_seen: True

## E3 Gate
- sample_origin_type: external_benchmark
- human_review_required: True
- human_review_completed: False
- human_review_decision: score_disabled
- score_valid: False
- human_review_disagreement: False
- e3_minimum_repeats: 5
- claim_scope: Terminal-Bench coding/file/debug/data-processing subset
- declared_validator_runtime: terminal_bench_equivalent_docker_app
- declared_official_runner_or_equivalent: True
- declared_agent_cannot_read_validator_source: True
- declared_validator_e3_eligible: True
- declared_validator_downgrade_reason: 
- e3_human_review_not_completed
- external_runtime_proof_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\external-runtime-proof.json
- external_runner_equivalence_proof_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\external-runner-equivalence-proof.json
- external_isolation_proof_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\external-isolation-proof.json
- external_combined_proof_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\external-e3-proof.json
- proof_official_runner_or_equivalent: True
- proof_agent_cannot_read_validator_source: True
- proof_validator_e3_eligible: True
- audit_review_source_path: 
- audit_review_failures: audit_review_missing

## Variable Control
- failures: none

## Prompt Guard
- invalid_prompt: False
- manual_review_required: False
- hard_hits: 
- context_hits: 

## Oracle Isolation Probe
- oracle_isolation_level: hard_deferred_materialization
- canary_leaked: False
- canary_materialized_during_probe: False
- path_mentioned: True
- jsonl: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\oracle-isolation-probe\whale-exec.jsonl

## Scenario Warnings
- none

## Utility Assessment
- outcome: score_disabled
- score_valid: False
- taskspace_tool_call_ratio: 1.6
- taskspace_wall_time_ratio: 3.05
- taskspace_tool_call_ratio_warn: False
- taskspace_wall_time_ratio_warn: False
- note: score fields disabled because engineering clean execution is not established; raw side outcomes are diagnostic only.

## left / taskspace
- business_success: False
- exec_exit_code: 0
- exec_timed_out: False
- public_validation_exit_code: 1
- hidden_oracle_exit_code: 0
- oracle_isolation_level: hard_sandbox
- wall_time_ms: 287828
- tool_call_count: 16
- changed_paths: debug_parse.py, log_extracted/__MACOSX/._log.stack, log_extracted/log.stack, output.txt
- changed_file_inventory: debug_parse.py[??] sha256=b5793ab631d449faada042cd761e850c891f976ff7222bd758ffd6a063a07db1 size=633; log_extracted/__MACOSX/._log.stack[??] sha256=8d297523b9b31f9fa400c67197df4f153085ce2970deb433338d7121e12e57a0 size=163; log_extracted/log.stack[??] sha256=6f73619ff6956bc1ee1ae2a9c6813cfb792c4b058eeb42e54a26da6e4339ed40 size=4073633; output.txt[??] sha256=0e9c4ebb95bb4062652f1d0f3d46b34618a03425a3838c2f1ba4fa372e2e4312 size=4964
- metrics_warnings: 
- metrics_taints: 
- validator_environment_failures: 
- docker_build_result_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\left\artifacts\vrun\docker-build-result.json
- validator_environment_mismatch: False
- maps: 1
- nodes: 6
- edges: 5
- edge_order_violations: 0
- spawn_agent_calls: 0
- subagent_results: 0
- open_leaf_nodes: 0
- ordinary_before_binding: False

## right / standard
- business_success: False
- exec_exit_code: 0
- exec_timed_out: False
- public_validation_exit_code: 1
- hidden_oracle_exit_code: 0
- oracle_isolation_level: hard_sandbox
- wall_time_ms: 94387
- tool_call_count: 10
- changed_paths: log_extracted/__MACOSX/._log.stack, log_extracted/log.stack, output.txt
- changed_file_inventory: log_extracted/__MACOSX/._log.stack[??] sha256=8d297523b9b31f9fa400c67197df4f153085ce2970deb433338d7121e12e57a0 size=163; log_extracted/log.stack[??] sha256=6f73619ff6956bc1ee1ae2a9c6813cfb792c4b058eeb42e54a26da6e4339ed40 size=4073633; output.txt[??] sha256=f149d3386af546951199689bf437b8de6b09390a66274889d47af41c97730d7e size=4966
- metrics_warnings: 
- metrics_taints: 
- validator_environment_failures: 
- docker_build_result_path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-002\right\artifacts\vrun\docker-build-result.json
- validator_environment_mismatch: False
- maps: 0
- nodes: 0
- edges: 0
- edge_order_violations: 0
- spawn_agent_calls: 0
- subagent_results: 0
- open_leaf_nodes: 0
- ordinary_before_binding: False
