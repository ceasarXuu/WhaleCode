﻿# Action Map Observability

## Source

- rollout path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-004\left\artifacts\rollout.jsonl
- jsonl path: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-004\left\artifacts\whale-exec.jsonl
- artifact root: D:\whalecode-alpha\target\e3-v004-proof-20260615\serial-clean-v1\suite-20260616-020714\samples\count-call-stack\runs\terminal_bench__count-call-stack\20260616-034150-446\pair-004\left\app
- rollout parse errors: 0
- jsonl parse errors: 0

## Summary

- maps: 2
- nodes: 7
- edges: 5
- agents: 0
- collab tool calls: 0
- map runtime events: 169
- output contracts: 2
- fact sources: 3
- accepted results: 4
- questioned/invalid results: 1
- final artifacts: 2
- cognitive structural gate: True
- cognitive hard gate: False
- full MVP hard gate implemented: True

## Cognitive Audit

- audit schema: taskspace-cognitive-audit-v1
- audit scope: mvp-final-artifact-why-chain
- promotion_not_in_mvp: True
- hard gate failures: audit_why_chain_missing, final_artifact_hash_missing
- unsupported MVP gates: 

### Gate Records

| Gate | Pass | Expected | Observed | Subject IDs |
|---|---|---|---|---|
| required_output_contract_missing | True | at least one output contract | outputContracts=2 |  |
| required_fact_source_missing | True | at least one fact source | factSources=3 |  |
| result_claims_evidence_missing | True | when results exist, at least one result has claims and evidence | results=14, resultWithClaimEvidence=5 |  |
| accepted_result_missing_evidence | True | accepted results include claims and evidence | acceptedMissingEvidence=0 |  |
| active_fact_source_missing | True | each active fact has a joinable factSourceId evidence ref | missingEvidenceRefs=0, missingJoinableSource=0 |  |
| self_generated_data_leakage | True | active facts do not rely on generated/inferred/unknown sources | invalidSourceRefs=0 |  |
| questioned_or_invalid_result_in_cognitive_state_update | True | active facts do not rely on questioned/invalid/cross-task results | invalidResultRefs=0 |  |
| result_validity_transition_missing | True | when results exist, at least one result validity transition is recorded | results=14, validityTransitions=6 |  |
| orphan_result_validity_transition | True | validity transition result ids join to snapshot results | orphanTransitions=0 |  |
| audit_why_chain_missing | False | final artifacts have output contract, result, claim, and evidence joins | missingWhyChain=1 | task-2/oc-final |
| final_artifact_hash_missing | False | each final artifact path resolves to a SHA-256 hash | missingHash=2 | task:task-1\|artifact:W:/app/output.txt, task:task-1\|artifact:W:/app/analyze_traces.py |
| output_contract_result_mismatch | True | artifact output contracts with explicit result refs match the final artifact result | mismatches=0 |  |
| non_accepted_final_artifact_dependency | True | final artifact dependencies use accepted results only | nonAcceptedDependencies=0 |  |
| questioned_or_invalid_final_artifact_dependency | True | final artifact dependencies do not use questioned/invalid results | badDependencies=0 |  |
| sentinel_warning_uncleared_for_final_artifact | True | sentinel warnings affecting final artifacts are cleared | unclearedSentinels=0 |  |

### Metrics

| Metric | Value |
|---|---|
| outputContractCount | 2 |
| factSourceCount | 3 |
| activeFactCount | 0 |
| resultCount | 14 |
| acceptedResultCount | 4 |
| questionedOrInvalidResultCount | 1 |
| acceptedResultMissingEvidenceCount | 0 |
| resultWithClaimEvidenceCount | 5 |
| activeFactMissingEvidenceRefCount | 0 |
| activeFactMissingJoinableSourceCount | 0 |
| invalidFactSourceReferenceCount | 0 |
| invalidResultFactReferenceCount | 0 |
| orphanResultValidityTransitionCount | 0 |
| resultValidityTransitionCount | 6 |
| cognitiveStateUpdateCount | 42 |
| activeSentinelWarningCount | 0 |
| finalArtifactCount | 2 |
| finalArtifactMissingHashCount | 2 |
| finalArtifactMissingWhyChainCount | 1 |
| outputContractResultMismatchCount | 0 |
| nonAcceptedFinalArtifactDependencyCount | 0 |
| questionedOrInvalidFinalArtifactDependencyCount | 0 |
| unclearedFinalArtifactSentinelCount | 0 |

## Tasks

| Task | Status | Title | Objective | Output Contracts | Fact Sources | Facts |
|---|---|---|---|---|---|---|
| task-2 | active | Stack trace final synthesis | Provide the final answer for the stack trace analysis task | 1 | 1 | 0 |
| task-1 | pending | Analyze profiling stack traces | Parse a log file containing stack traces, identify unique call sites based on top 3 frames, and output top 10 most common call sites sorted by frequency to /app/output.txt | 1 | 2 | 0 |

## Nodes

| Node | Kind | Title | Status | Agents | Results | Accepted | Questioned/Invalid | Blocked Actions | Active Barriers |
|---|---|---|---|---|---|---|---|---|---|
| node-5 | final_synthesis | Synthesize results | blocked | 0 | 1 | 1 | 0 | 0 | 0 |
| node-6 | final_synthesis | Final synthesis | ready | 0 | 0 | 0 | 0 | 0 | 0 |
| node-4 | inspect_code_context | Run analysis and verify output | completed | 0 | 3 | 1 | 0 | 2 | 0 |
| node-2 | implement_solution | Parse stack traces and generate output | completed | 0 | 2 | 1 | 0 | 2 | 0 |
| node-1 | inspect_code_context | Find and inspect input log file | completed | 0 | 6 | 1 | 0 | 1 | 0 |
| node-3 | smoke_test | Run stack trace analysis | blocked | 0 | 1 | 0 | 1 | 2 | 0 |
| node-7 | final_synthesis | Final report | blocked | 0 | 1 | 0 | 0 | 0 | 0 |

## Final Artifacts

| Artifact | Task | Path | Hash | Results | Contracts | Claims | Evidence Refs | Validators | Fact Sources | Sentinels |
|---|---|---|---|---|---|---|---|---|---|---|
| task:task-1\|artifact:W:/app/output.txt | task-1 | W:/app/output.txt |  | result-12 | oc-1 | c-5 | artifactRef=W:/app/output.txt |  |  |  |
| task:task-1\|artifact:W:/app/analyze_traces.py | task-1 | W:/app/analyze_traces.py |  | result-8 | oc-1 | c-3 | artifactRef=W:/app/analyze_traces.py |  |  |  |

## Result Evidence

| Result | Node | Validity | Claims | Evidence Refs | Validators | Reason |
|---|---|---|---|---|---|---|
| result-13 | node-5 | accepted | c-block-2 | {"resultId":"result-13","claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":null,"validatorRef":null} |  | Blocked due to runtime state, but replaced by node-6 for final synthesis |
| result-10 | node-4 | unreviewed |  |  |  |  |
| result-11 | node-4 | unreviewed |  |  |  |  |
| result-12 | node-4 | accepted | c-5 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/output.txt","validatorRef":null} |  | Script executed successfully and output.txt was written with correct format. Parsed 646 traces, 318 unique call sites, top 10 reported. |
| result-7 | node-2 | unreviewed |  |  |  |  |
| result-8 | node-2 | accepted | c-3 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/analyze_traces.py","validatorRef":null} |  | Created analyze_traces.py script file successfully |
| result-1 | node-1 | unreviewed |  |  |  |  |
| result-2 | node-1 | unreviewed |  |  |  |  |
| result-3 | node-1 | unreviewed |  |  |  |  |
| result-4 | node-1 | unreviewed |  |  |  |  |
| result-5 | node-1 | unreviewed |  |  |  |  |
| result-6 | node-1 | accepted | c-1, c-2 | {"resultId":null,"claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":"W:/app/log_stack/log.stack","validatorRef":null} |  | Found and extracted log.file, confirmed file structure from first 50 lines output |
| result-9 | node-3 | questioned | c-4 | {"resultId":"result-9","claimId":null,"factSourceId":null,"traceEventId":null,"artifactRef":null,"validatorRef":null} |  | Node blocked due to runtime tool classification, not a code issue. Script analyze_traces.py exists and needs execution. |
| result-14 | node-7 | unreviewed |  |  |  |  |

## Sentinel Warnings

| Sentinel | Type | Severity | Status | Task | Map | Node | Result | Trace Events | Reason | Clearance | Cleared By | Clear Events |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Edges

| From | To |
|---|---|
| node-1 | node-2 |
| node-2 | node-3 |
| node-2 | node-4 |
| node-4 | node-5 |
| node-4 | node-6 |

## Timeline

- 2026-06-15T20:08:05.292Z **mode_changed** mode changed: standard -> experiment
- 2026-06-15T20:08:07.873Z **task_created** task created: task-1 Analyze profiling stack traces
- 2026-06-15T20:08:07.874Z **map_created** map created: map-1 Analyze profiling stack traces
- 2026-06-15T20:08:07.874Z **node_status_changed** node status: node-1 pending -> ready
- 2026-06-15T20:08:07.875Z **node_status_changed** node status: node-1 ready -> running
- 2026-06-15T20:08:07.875Z **lease_created** lease created: lease-1 on node-1
- 2026-06-15T20:08:07.876Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:13.127Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:08:13.127Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:08:13.128Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:08:13.128Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:13.131Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-1
- 2026-06-15T20:08:13.131Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:13.132Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-user-req
- 2026-06-15T20:08:13.132Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:20.194Z **node_result_recorded** node result recorded: node-1 / result-1 action=read
- 2026-06-15T20:08:20.195Z **taskspace_trace_event_recorded** trace event: trace-1 result=result-1 tags=tool_success
- 2026-06-15T20:08:20.196Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:24.785Z **node_result_recorded** node result recorded: node-1 / result-2 action=read
- 2026-06-15T20:08:24.785Z **taskspace_trace_event_recorded** trace event: trace-2 result=result-2 tags=tool_success
- 2026-06-15T20:08:24.786Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:28.972Z **node_result_recorded** node result recorded: node-1 / result-3 action=read
- 2026-06-15T20:08:28.972Z **taskspace_trace_event_recorded** trace event: trace-3 result=result-3 tags=tool_success
- 2026-06-15T20:08:28.973Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:35.744Z **node_result_recorded** node result recorded: node-1 / result-4 action=read
- 2026-06-15T20:08:35.744Z **taskspace_trace_event_recorded** trace event: trace-4 result=result-4 tags=tool_success
- 2026-06-15T20:08:35.745Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:41.393Z **node_result_recorded** node result recorded: node-1 / result-5 action=read
- 2026-06-15T20:08:41.394Z **taskspace_trace_event_recorded** trace event: trace-5 result=result-5 tags=tool_success
- 2026-06-15T20:08:41.394Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:49.434Z **tool_action_blocked** tool action blocked: node-1 edit via shell_command
- 2026-06-15T20:08:49.434Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:53.264Z **node_result_recorded** node result recorded: node-1 / result-6
- 2026-06-15T20:08:53.264Z **lease_released** lease released: lease-1, reason=result_recorded
- 2026-06-15T20:08:53.265Z **node_status_changed** node status: node-1 running -> completed
- 2026-06-15T20:08:53.265Z **snapshot_updated** snapshot updated: maps=1 nodes=1
- 2026-06-15T20:08:55.714Z **node_status_changed** node status: node-2 pending -> ready
- 2026-06-15T20:08:55.714Z **node_status_changed** node status: node-2 ready -> running
- 2026-06-15T20:08:55.715Z **lease_created** lease created: lease-2 on node-2
- 2026-06-15T20:08:55.715Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:08:57.998Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-log-file
- 2026-06-15T20:08:57.998Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:09:03.574Z **result_validity_changed** result validity: result-6 -> accepted
- 2026-06-15T20:09:03.574Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:09:05.513Z **tool_action_blocked** tool action blocked: node-2 unknown via shell_command
- 2026-06-15T20:09:05.513Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:09:14.084Z **node_result_recorded** node result recorded: node-2 / result-7 action=edit
- 2026-06-15T20:09:14.085Z **taskspace_trace_event_recorded** trace event: trace-6 result=result-7 tags=tool_success
- 2026-06-15T20:09:14.085Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:09:15.598Z **tool_action_blocked** tool action blocked: node-2 unknown via shell_command
- 2026-06-15T20:09:15.599Z **snapshot_updated** snapshot updated: maps=1 nodes=2
- 2026-06-15T20:09:19.178Z **node_result_recorded** node result recorded: node-2 / result-8
- 2026-06-15T20:09:19.178Z **lease_released** lease released: lease-2, reason=result_recorded
- 2026-06-15T20:09:19.178Z **node_status_changed** node status: node-2 running -> completed
- 2026-06-15T20:09:19.179Z **node_status_changed** node status: node-3 pending -> ready
- 2026-06-15T20:09:19.179Z **node_status_changed** node status: node-3 ready -> running
- 2026-06-15T20:09:19.179Z **lease_created** lease created: lease-3 on node-3
- 2026-06-15T20:09:19.180Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:09:21.427Z **result_validity_changed** result validity: result-8 -> accepted
- 2026-06-15T20:09:21.427Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:09:22.874Z **tool_action_blocked** tool action blocked: node-3 unknown via shell_command
- 2026-06-15T20:09:22.875Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:09:25.531Z **tool_action_blocked** tool action blocked: node-3 edit via shell_command
- 2026-06-15T20:09:25.531Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:09:31.748Z **node_result_recorded** node result recorded: node-3 / result-9
- 2026-06-15T20:09:31.748Z **lease_released** lease released: lease-3, reason=result_recorded
- 2026-06-15T20:09:31.749Z **node_status_changed** node status: node-3 running -> blocked
- 2026-06-15T20:09:31.749Z **snapshot_updated** snapshot updated: maps=1 nodes=3
- 2026-06-15T20:09:37.732Z **node_status_changed** node status: node-4 pending -> ready
- 2026-06-15T20:09:37.733Z **node_status_changed** node status: node-4 ready -> running
- 2026-06-15T20:09:37.733Z **lease_created** lease created: lease-4 on node-4
- 2026-06-15T20:09:37.733Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:09:44.222Z **result_validity_changed** result validity: result-9 -> questioned
- 2026-06-15T20:09:44.222Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:09:46.030Z **tool_action_blocked** tool action blocked: node-4 unknown via shell_command
- 2026-06-15T20:09:46.031Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:09:48.765Z **tool_action_blocked** tool action blocked: node-4 unknown via shell_command
- 2026-06-15T20:09:48.765Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:09:53.593Z **node_result_recorded** node result recorded: node-4 / result-10 action=read
- 2026-06-15T20:09:53.594Z **taskspace_trace_event_recorded** trace event: trace-7 result=result-10 tags=tool_success
- 2026-06-15T20:09:53.594Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:10:01.695Z **node_result_recorded** node result recorded: node-4 / result-11 action=read
- 2026-06-15T20:10:01.695Z **taskspace_trace_event_recorded** trace event: trace-8 result=result-11 tags=tool_success
- 2026-06-15T20:10:01.696Z **snapshot_updated** snapshot updated: maps=1 nodes=4
- 2026-06-15T20:10:07.618Z **node_result_recorded** node result recorded: node-4 / result-12
- 2026-06-15T20:10:07.618Z **lease_released** lease released: lease-4, reason=result_recorded
- 2026-06-15T20:10:07.618Z **node_status_changed** node status: node-4 running -> completed
- 2026-06-15T20:10:07.619Z **node_status_changed** node status: node-5 pending -> ready
- 2026-06-15T20:10:07.619Z **node_status_changed** node status: node-5 ready -> running
- 2026-06-15T20:10:07.619Z **lease_created** lease created: lease-5 on node-5
- 2026-06-15T20:10:07.620Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:10:12.057Z **result_validity_changed** result validity: result-12 -> accepted
- 2026-06-15T20:10:12.058Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:10:14.495Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:10:14.496Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:10:14.496Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:10:14.496Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:10:25.689Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:10:25.689Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:10:25.689Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:10:25.690Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:10:30.811Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-1
- 2026-06-15T20:10:30.811Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:10:35.983Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:10:35.983Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:10:35.983Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:10:35.984Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:10:41.689Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final-1
- 2026-06-15T20:10:41.689Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final-2
- 2026-06-15T20:10:41.690Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final-3
- 2026-06-15T20:10:41.690Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:10:47.020Z **node_result_recorded** node result recorded: node-5 / result-13
- 2026-06-15T20:10:47.021Z **lease_released** lease released: lease-5, reason=result_recorded
- 2026-06-15T20:10:47.021Z **node_status_changed** node status: node-5 running -> blocked
- 2026-06-15T20:10:47.022Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:10:51.847Z **result_validity_changed** result validity: result-13 -> unreviewed
- 2026-06-15T20:10:51.847Z **snapshot_updated** snapshot updated: maps=1 nodes=5
- 2026-06-15T20:10:53.849Z **node_status_changed** node status: node-6 pending -> ready
- 2026-06-15T20:10:53.849Z **node_status_changed** node status: node-6 ready -> running
- 2026-06-15T20:10:53.849Z **lease_created** lease created: lease-6 on node-6
- 2026-06-15T20:10:53.850Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T20:11:00.546Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:11:00.547Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:11:00.547Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:11:00.547Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final-1
- 2026-06-15T20:11:00.548Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final-2
- 2026-06-15T20:11:00.548Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final-3
- 2026-06-15T20:11:00.548Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T20:11:05.251Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:11:05.252Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:11:05.252Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:11:05.252Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T20:11:10.698Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-1
- 2026-06-15T20:11:10.699Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-2
- 2026-06-15T20:11:10.699Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-3
- 2026-06-15T20:11:10.699Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final-1
- 2026-06-15T20:11:10.700Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final-2
- 2026-06-15T20:11:10.700Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-final-3
- 2026-06-15T20:11:10.700Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T20:11:14.979Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-2
- 2026-06-15T20:11:14.980Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T20:11:23.131Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s1
- 2026-06-15T20:11:23.132Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s2
- 2026-06-15T20:11:23.132Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-s3
- 2026-06-15T20:11:23.133Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T20:11:30.951Z **result_validity_changed** result validity: result-13 -> accepted
- 2026-06-15T20:11:30.952Z **snapshot_updated** snapshot updated: maps=1 nodes=6
- 2026-06-15T20:11:39.353Z **lease_released** lease released: lease-6, reason=task_started
- 2026-06-15T20:11:39.354Z **node_status_changed** node status: node-6 running -> ready
- 2026-06-15T20:11:39.354Z **task_status_changed** task status: task-1 active -> pending
- 2026-06-15T20:11:39.354Z **task_created** task created: task-2 Stack trace final synthesis
- 2026-06-15T20:11:39.355Z **map_created** map created: map-2 Stack trace final synthesis
- 2026-06-15T20:11:39.355Z **node_status_changed** node status: node-7 pending -> ready
- 2026-06-15T20:11:39.355Z **snapshot_updated** snapshot updated: maps=2 nodes=7
- 2026-06-15T20:11:42.941Z **cognitive_state_updated** cognitive state updated: problem_ledger.success_criterion sc-done
- 2026-06-15T20:11:42.941Z **snapshot_updated** snapshot updated: maps=2 nodes=7
- 2026-06-15T20:11:42.943Z **cognitive_state_updated** cognitive state updated: problem_ledger.output_contract oc-final
- 2026-06-15T20:11:42.944Z **snapshot_updated** snapshot updated: maps=2 nodes=7
- 2026-06-15T20:11:42.946Z **cognitive_state_updated** cognitive state updated: problem_ledger.fact_source fs-final
- 2026-06-15T20:11:42.946Z **snapshot_updated** snapshot updated: maps=2 nodes=7
- 2026-06-15T20:11:45.098Z **cognitive_state_updated** cognitive state updated: problem_ledger.decision d-final
- 2026-06-15T20:11:45.098Z **snapshot_updated** snapshot updated: maps=2 nodes=7
- 2026-06-15T20:11:51.619Z **node_status_changed** node status: node-7 ready -> running
- 2026-06-15T20:11:51.619Z **lease_created** lease created: lease-7 on node-7
- 2026-06-15T20:11:51.619Z **snapshot_updated** snapshot updated: maps=2 nodes=7
- 2026-06-15T20:11:54.174Z **node_result_recorded** node result recorded: node-7 / result-14
- 2026-06-15T20:11:54.174Z **lease_released** lease released: lease-7, reason=result_recorded
- 2026-06-15T20:11:54.175Z **node_status_changed** node status: node-7 running -> blocked
- 2026-06-15T20:11:54.175Z **snapshot_updated** snapshot updated: maps=2 nodes=7

## Known Missing / Future Work

- This report validates the MVP final-artifact why-chain by mechanically joining output contracts, results, claims, evidence refs, validators/fact sources, sentinel warnings, and artifact hashes.
- Final artifacts are currently derived from artifact output contracts and result `changedArtifacts` / `artifactRef` fields; a dedicated final-artifact runtime event remains future work.
- Browser interaction coverage for /task-show remains separate from this static export report.
