The analysis is complete. Here's the summary:

**W:\app\access_log Analysis**

| Statistic | Value |
|---|---|
| **Total requests** | 2,000 |
| **Unique IP addresses** | 273 |
| **404 errors** | 83 |

**Top 3 URLs:**
1. `/order-confirmation` — 54 requests
2. `/product/456` — 53 requests
3. `/about.html` — 52 requests

**Output file created:** `W:\app\report.txt`

The report contains the exact format requested:
```
Total requests: 2000
Unique IP addresses: 273
Top 3 URLs:
  /order-confirmation: 54
  /product/456: 53
  /about.html: 52
404 errors: 83
```

The analysis was performed by parsing the Apache-style access log (2000 entries), extracting IP addresses, request URLs from the HTTP method lines, and HTTP status codes. All values were computed via PowerShell and validated against the source data.